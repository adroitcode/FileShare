package net.com.codeusa.model.quest;

/**
 * @author Codeusa
 */

interface Quest {

	void addQuestScroll();

	void setQuestId(int questId);

}