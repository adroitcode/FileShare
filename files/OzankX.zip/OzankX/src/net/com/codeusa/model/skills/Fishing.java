package net.com.codeusa.model.skills;

/**
 * @author Codeusa
 */

interface Fishing {

	void handleAttempting();

}