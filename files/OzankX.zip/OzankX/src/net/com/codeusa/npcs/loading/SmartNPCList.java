package net.com.codeusa.npcs.loading;

public class SmartNPCList {

	public int ID;
	public int index;
	public int intelligence;
	public int hitpoints;
	public int attack;
	public int strength;
	public int defence;
	public int ranged;
	public int magic;

	public SmartNPCList(int ID, int index, int intelligence, int hitpoints, int attack, int strength, int defence, int ranged, int magic) {
		this.ID = id;
		this.index = index;
		this.itelligence = intelligence;
		this.hitpoints = hitpoints;
		this.attack = attack;
		this.strength = strength;
		this.defence = defence;
		this.ranged = ranged;
		this.magic = magic;
	}

}