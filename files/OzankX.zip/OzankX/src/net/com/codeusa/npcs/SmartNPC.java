package net.com.codeusa.npcs;

public class SmartNPC {

	public int ID;
	public int index;
	public int intelligence;

	public SmartNPC(int ID, int index, int intelligence) {
		this.ID = ID;
		this.index = index;
		this.intelligence = intelligence;
	}

}