package net.com.codeusa.npcs.loading;

/**
 * @author Codeusa
 */

public class NpcDrops {

	public static int randomKbd[] = {
		1149, 4587
	};

	public static int getKbdDrop() {
		return randomKbd[(int)(Math.random()*randomKbd.length)];
	}

	public static int randomMithDrag[] = {
		1149, 1163
	};

	public static int getMithDragDrop() {
		return randomMithDrag[(int)(Math.random()*randomMithDrag.length)];
	}

	public static int randomQueen[] = {
		1305, 4587, 1215, 391, 385, 1704, 1127, 1079, 1163, 3140, 3204, 229
	};

	public static int getQueenDrop() {
		return randomQueen[(int)(Math.random()*randomQueen.length)];
	}

	public static int randomTsusaroth[] = {
		995, 995, 995, 995, 2503, 892, 11708, 995, 995, 995, 995, 11690, 995, 995, 995, 995, 2503, 2503, 2497, 995, 592, 592, 592, 592, 592
	};

	public static int getKrilTsusarothDrop() {
		return randomTsusaroth[(int)(Math.random()*randomTsusaroth.length)];
	}

	public static int randomKree[] = {
		1149, 11718, 11720, 11722, 2503, 892, 185, 884, 11694, 995, 995, 1149, 1149, 995, 995, 995, 892, 892, 11718, 995, 995, 11720, 892, 892, 2503, 2497, 9179, 11722, 995,
		11690, 2503, 892, 892, 892, 2434, 2434, 11702
	};

	public static int getKreeArraDrop() {
		return randomKree[(int)(Math.random()*randomKree.length)];
	}

	public static int randomAbyssal[] = {
		199, 199, 199, 592, 592, 199, 201, 209, 592, 4151, 592, 1149, 884, 995, 995, 592, 592, 592, 592, 199, 199, 199, 199, 199
	};

	public static int getAbyssalDrop() {
		return randomAbyssal[(int)(Math.random()*randomAbyssal.length)];
	}

	public static int randomGraardor[] = {
		199, 199, 526, 449, 451, 561, 11728, 199, 449, 449, 451, 199, 11726, 1149, 1149, 560, 560, 199, 201, 201, 201, 201, 1513, 1513, 199, 201,
		11696, 199, 199, 201, 451, 451, 560, 561, 995, 11724, 1201, 1127, 199, 201, 201, 451, 995, 451, 451, 451, 532, 532, 1731, 11704, 11690
	};

	public static int getGraardorDrop() {
		return randomGraardor[(int)(Math.random()*randomGraardor.length)];
	}

	public static int randomRevenantOrk[] = {
		1215, 5698, 1704, 1731, 1113, 6568
	};

	public static int getRevenantOrkDrop() {
		return randomRevenantOrk[(int)(Math.random()*randomRevenantOrk.length)];
	}

	public static int randomZilyana[] = {
		2434, 2434, 2434, 2434, 1319, 1123, 3024, 3026, 11706, 3028, 3030, 6685, 6687, 6689, 6691, 995, 11730, 561, 11690, 561, 561, 2434, 1319
	};

	public static int getZilyanaDrop() {
		return randomZilyana[(int)(Math.random()*randomZilyana.length)];
	}

	public static int randomBronze[] = {
		199, 199, 199, 201, 199, 8844, 199, 199, 199, 199, 199,199, 199, 201, 203, 1731, 201, 201, 201, 199, 199, 199, 203, 175, 201, 199
	};

	public static int getBronzeDefDrop() {
		return randomBronze[(int)(Math.random()*randomBronze.length)];
	}

	public static int randomIron[] = {
		199, 199, 199, 201, 199, 8845, 199, 199, 199, 199, 199, 199, 199, 201, 203, 1731, 201, 201, 201, 199, 199, 199, 203, 175, 201, 199
	};

	public static int getIronDefDrop() {
		return randomIron[(int)(Math.random()*randomIron.length)];
	}

	public static int randomDark[] = {
		1731, 1731, 995, 995, 199, 199, 201, 201, 199, 199, 199, 1731, 1731, 1704, 995, 995, 995, 199, 11235, 995, 201, 1731
	};

	public static int getDarkBeastDrop() {
		return randomDark[(int)(Math.random()*randomDark.length)];
	}

	public static int randomGargoyle[] = {
		4101, 995, 995, 995, 560, 560, 995, 995, 995, 560, 560, 1163, 4101, 995, 995, 4129, 4129, 995, 995, 4153, 4153, 995, 995, 4129, 995, 560, 560, 560, 560, 4103, 995
	};

	public static int getGargoyleDrop() {
		return randomGargoyle[(int)(Math.random()*randomGargoyle.length)];
	}

}