/*
 * Class ItemOption1
 *
 * Version 1.0
 *
 * Thursday, August 21, 2008
 *
 * Created by Palidino76
 */

package net.com.codeusa.net.packethandler;

import net.com.codeusa.*;
import net.com.codeusa.model.misc.*;
import net.com.codeusa.model.Player;
import net.com.codeusa.util.Misc;

public class ItemOption1 implements Packet {
    /**
     * Handles first item options, excluding things such as eating and drinking.
     * @param p The Player which the frame should be handled for.
     * @param packetId The packet id this belongs to.
     * @param packetSize The amount of bytes being recieved for this packet.
     */
    public void handlePacket(Player p, int packetId, int packetSize) {
        if (p == null || p.stream == null) {
            return;
        }
        int itemSlot = p.stream.readUnsignedWordBigEndianA();
        int interfaceId = p.stream.readUnsignedWord();
        int junk = p.stream.readUnsignedWord();
        int itemId = p.stream.readUnsignedWord();
        if (itemSlot < 0 || itemId < 0) {
            return;
        }
        switch (interfaceId) {
        case 387: // Unequip item.
            if (itemSlot < p.equipment.length && p.equipment[itemSlot] == itemId) {
                if (!Engine.playerItems.addItem(p, p.equipment[itemSlot], p.equipmentN[itemSlot])) {
                    break;
                }
		if (itemId == 4031) {
			p.convertPlayerToNpc(-1);
			p.updatePlayerAppearance(p.playerWeapon.getWalkEmote(p.equipment[3]), p.playerWeapon.getStandEmote(p.equipment[3]),
				p.playerWeapon.getRunEmote(p.equipment[3]));
			p.updatePlayer(true);
		}
		if (itemId == 4675 || itemId == 9084) {
			p.getActionSender().setTab(p, 79, 192);
		}
		if (itemId == 4037 || itemId == 4039) {
			Server.engine.items.createGroundItem(itemId, p.itemsN[itemSlot], p.absX, p.absY, p.heightLevel, "");
			Server.engine.playerItems.deleteItem(p, itemId, Server.engine.playerItems.getItemSlot(p, itemId), 1);
		}
		if (itemId == 3053) {
			p.getActionSender().sendMessage(p, "You cannot un-equip your battlestaff while during the mage arena minigame.");
			return;
		}
		if (p.usingAutoCast) {
			p.castAuto = false;
			p.usingAutoCast = false;
			p.autoCastDelay = 0;
		}
                p.equipment[itemSlot] = -1;
                p.equipmentN[itemSlot] = 0;
	    	PlayerMethods pm = new PlayerMethods(p);
	    	pm.setAttackPlayer(false);
                p.getActionSender().setItems(p, 387, 28, 94, p.equipment, p.equipmentN);
                p.playerWeapon.setWeapon();
                p.appearanceUpdateReq = true;
                p.updateReq = true;
                p.calculateEquipmentBonus();
            }
            break;
        default:
            Misc.println("[" + p.username + "] Item option 1: " + interfaceId);
            break;
        }
    }
}
