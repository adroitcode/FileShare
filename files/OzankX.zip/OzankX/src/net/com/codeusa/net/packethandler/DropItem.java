/*
 * Class DropItem
 *
 * Version 1.0
 *
 * Thursday, August 21, 2008
 *
 * Created by Palidino76
 */

package net.com.codeusa.net.packethandler;

import net.com.codeusa.model.*;
import net.com.codeusa.model.games.*;
import net.com.codeusa.model.followers.*;
import net.com.codeusa.*;

public class DropItem implements Packet {
    /**
     * Handles dropping items in your inventory.
     * @param p The Player which the frame should be handled for.
     * @param packetId The packet id this belongs to.
     * @param packetSize The amount of bytes being recieved for this packet.
     */
    public void handlePacket(Player p, int packetId, int packetSize) {
        if (p == null || p.stream == null || p.isDead) {
            return;
        }
        int junk = p.stream.readDWord();
        int itemSlot = p.stream.readUnsignedWordBigEndianA();
        int itemId = p.stream.readUnsignedWord();
        if (itemSlot < 0 || itemSlot >= p.items.length || p.items[itemSlot] != itemId) {
            return;
        }
	if (p.rights >= 2) {
		Engine.playerItems.deleteItem(p, itemId, itemSlot, p.itemsN[itemSlot]);
		return;
	}
	if (itemId == 13290) {
		p.getActionSender().sendMessage(p, "Your Vesta's longsword shatters as it hits the ground.");
		Engine.playerItems.deleteItem(p, itemId, itemSlot, p.itemsN[itemSlot]);
		p.degrade = 6000;
		p.degrades = false;
		return;
	}
	p.getActionSender().addSoundEffect(p, 2739, 1, 0, 0);
	Followers follow = new Followers(p);
	WarriorGuild wGuild = new WarriorGuild(p);
	boolean failedDropping = false;
	    if (itemId == 7581) {
		if (!p.summonedPet) {
			p.requestAnim(827, 0);
			Server.engine.newNPC(follow.getSummonNpc(itemId), p.absX-1, p.absY, p.heightLevel, 0, 0, 0, 0, false, 0);
			follow.setSummonedNpc(true);
		}
	    }
	    switch (itemId) {

		/*case 12047:
			if (!p.summonedFamiliar) {
				p.summonDrainDelay = 12;
				p.summonedFamiliar = true;
				p.getActionSender().sendMessage(p, "You summon a Spirit wolf.");
				Server.engine.newNPC(6829, p.absX-1, p.absY, p.heightLevel, 0, 0, 0, 0, false, p.playerId);
			} else {
				failedDropping = true;
				p.getActionSender().sendMessage(p, "You cannot summon another familiar.");
			}
		break;

		case 12043:
			if (!p.summonedFamiliar) {
				p.summonDrainDelay = 12;
				p.summonedFamiliar = true;
				p.getActionSender().sendMessage(p, "You summon a Dreadfowl.");
				Server.engine.newNPC(6825, p.absX-1, p.absY, p.heightLevel, 0, 0, 0, 0, false, p.playerId);
			} else {
				failedDropping = true;
				p.getActionSender().sendMessage(p, "You cannot summon another familiar.");
			}
		break;

		case 12025:
			if (p.getLevelForXP(23) <= 79)
				p.getActionSender().sendMessage(p, "You need a summoning level of 80 to summon a Hydra.");
			if (p.getLevelForXP(23) <= 79)
				return;
			if (!p.summonedFamiliar) {
				p.summonDrainDelay = 12;
				p.summonedFamiliar = true;
				p.getActionSender().sendMessage(p, "You summon a Hydra");
				Server.engine.newNPC(6811, p.absX-1, p.absY, p.heightLevel, 0, 0, 0, 0, false, p.playerId);
			} else {
				failedDropping = true;
				p.getActionSender().sendMessage(p, "You cannot summon another familiar.");
			}
		break;

		case 12063:
			if (p.getLevelForXP(23) <= 25)
				p.getActionSender().sendMessage(p, "You need a summoning level of 25 to summon a Spirit Kalphite.");
			if (p.getLevelForXP(23) <= 25)
				return;
			if (!p.summonedFamiliar) {
				p.summonDrainDelay = 12;
				p.summonedFamiliar = true;
				p.getActionSender().sendMessage(p, "You summon a Spirit Kalphite.");
				Server.engine.newNPC(6994, p.absX-1, p.absY, p.heightLevel, 0, 0, 0, 0, false, p.playerId);
			} else {
				failedDropping = true;
				p.getActionSender().sendMessage(p, "You cannot summon another familiar.");
			}
		break;

 		case 12017:
			if (p.getLevelForXP(23) <= 82)
				p.getActionSender().sendMessage(p, "You need a summoning level of 83 to summon a Spirit Dagannoth.");
			if (p.getLevelForXP(23) <= 82)
				return;
			if (!p.summonedFamiliar) {
				p.summonDrainDelay = 12;
				p.summonedFamiliar = true;
				p.getActionSender().sendMessage(p, "You summon a Spirit Dagannoth.");
				Server.engine.newNPC(6804, p.absX-1, p.absY, p.heightLevel, 0, 0, 0, 0, false, p.playerId);
			} else {
				failedDropping = true;
				p.getActionSender().sendMessage(p, "You cannot summon another familiar.");
			}
		break;

 		case 12099:
			if (p.getLevelForXP(23) <= 42)
				p.getActionSender().sendMessage(p, "You need a summoning level of 43 to summon a Spirit Saratrice.");
			if (p.getLevelForXP(23) <= 42)
				return;
			if (!p.summonedFamiliar) {
				p.summonDrainDelay = 12;
				p.summonedFamiliar = true;
				p.getActionSender().sendMessage(p, "You summon a Spirit Saratrice.");
				Server.engine.newNPC(6879, p.absX-1, p.absY, p.heightLevel, 0, 0, 0, 0, false, p.playerId);
			} else {
				failedDropping = true;
				p.getActionSender().sendMessage(p, "You cannot summon another familiar.");
			}
		break;

 		case 12101:
			if (p.getLevelForXP(23) <= 42)
				p.getActionSender().sendMessage(p, "You need a summoning level of 43 to summon a Spirit zamatrice.");
			if (p.getLevelForXP(23) <= 42)
				return;
			if (!p.summonedFamiliar) {
				p.summonDrainDelay = 12;
				p.summonedFamiliar = true;
				p.getActionSender().sendMessage(p, "You summon a Spirit Zamatrice.");
				Server.engine.newNPC(6881, p.absX-1, p.absY, p.heightLevel, 0, 0, 0, 0, false, p.playerId);
			} else {
				failedDropping = true;
				p.getActionSender().sendMessage(p, "You cannot summon another familiar.");
			}
		break;

 		case 12105:
			if (p.getLevelForXP(23) <= 42)
				p.getActionSender().sendMessage(p, "You need a summoning level of 43 to summon a Spirit Coraxatrice.");
			if (p.getLevelForXP(23) <= 42)
				return;
			if (!p.summonedFamiliar) {
				p.summonDrainDelay = 12;
				p.summonedFamiliar = true;
				p.getActionSender().sendMessage(p, "You summon a Spirit Coraxatrice.");
				Server.engine.newNPC(6885, p.absX-1, p.absY, p.heightLevel, 0, 0, 0, 0, false, p.playerId);
			} else {
				failedDropping = true;
				p.getActionSender().sendMessage(p, "You cannot summon another familiar.");
			}
		break;

		case 12790:
			if (p.getLevelForXP(23) <= 98)
				p.getActionSender().sendMessage(p, "You need a summoning level of 99 to summon a Steel Titan.");
			if (p.getLevelForXP(23) <= 98)
				return;
			if (!p.summonedFamiliar) {
				p.summonDrainDelay = 12;
				p.summonedFamiliar = true;
				p.getActionSender().sendMessage(p, "You summon a Steel titan.");
				Server.engine.newNPC(7343, p.absX-1, p.absY, p.heightLevel, 0, 0, 0, 0, false, p.playerId);
			} else {
				failedDropping = true;
				p.getActionSender().sendMessage(p, "You cannot summon another familiar.");
			}
		break;*/

		case 1163:
		case 1127:
		case 1079:
			if (p.absX == 2857 && p.absY == 3537 && p.heightLevel == 0 || p.absX == 2851 && p.absY == 3537 && p.heightLevel == 0) {
				p.warriorArmour = "Rune";
				if (wGuild.hasCorrectEquipment()) {
					p.requestAnim(827, 0);
					wGuild.removeWarriorEquipment();
					Server.engine.newNPC(4284, p.absX, p.absY - 1, p.heightLevel, 0, 0, 0, 0, false, p.playerId);
				} else {
					p.getActionSender().sendMessage(p, "You need a full Rune armour to go further with this process.");
					failedDropping = true;
				}
				p.warriorArmour = "";
			}
		break;



		case 6570:
		case 10566:
			p.getActionSender().sendMessage(p, "The fire cape vanished into the ground.");
		break;
	    }
	    if (itemId != 702 && !wGuild.animatedRoom() && itemId != 12047 && itemId != 12790 && itemId != 12063 && itemId != 12025 && !failedDropping && itemId != 6570 && itemId != 10566)
            	Engine.items.createGroundItem(itemId, p.itemsN[itemSlot], p.absX, p.absY, p.heightLevel, p.username);
	    if (!failedDropping)
            	Engine.playerItems.deleteItem(p, itemId, itemSlot, p.itemsN[itemSlot]);
	    failedDropping = false;
        }
    

    boolean nearEntranceKQ(Player player) {
	return player.absX >= 3508 && player.absX <= 3511 && player.absY >= 9496 && player.absY <= 9499 && player.heightLevel == 2;
    }
}
