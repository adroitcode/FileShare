/*
 * Class ItemSelect
 *
 * Version 1.0
 *
 * Friday, August 22, 2008
 *
 * Created by Palidino76
 */

package net.com.codeusa.net.packethandler;

import net.com.codeusa.*;
import net.com.codeusa.model.Player;
import net.com.codeusa.util.Misc;

public class ItemSelect implements Packet {
    /**
     * Handles certain item selecting such as eating and drinking.
     * @param p The Player which the frame should be handled for.
     * @param packetId The packet id this belongs to.
     * @param packetSize The amount of bytes being recieved for this packet.
     */
    public void handlePacket(Player p, int packetId, int packetSize) {
        if (p == null || p.stream == null) {
            return;
        }
        int junk = p.stream.readUnsignedByte();
        int interfaceId = p.stream.readUnsignedWord();
        junk = p.stream.readUnsignedByte();
        int itemId = p.stream.readUnsignedWordBigEndian();
        int itemSlot = p.stream.readUnsignedWordA();
        p.attackingPlayer = false;
        if (itemSlot < 0 || itemSlot > p.items.length || p.items[itemSlot] != itemId) {
            return;
        }
        if (p.isDead || p.skillLvl[3] < 1) {
            return;
        }
	int lastHP = 0;
        if (interfaceId == 149) {

		int addID = 0;

		switch (itemId) {

			//Potions

			case 2428: //Attack
				addID = 121;
			break;
			case 121:
				addID = 123;
			break;
			case 123:
				addID = 125;
			break;
			case 125:
				addID = 229;
			break;

			case 113: //Strength
				addID = 115;
			break;
			case 115:
				addID = 117;
			break;
			case 117:
				addID = 119;
			break;
			case 119:
				addID = 229;
			break;

			case 2432: //Defence
				addID = 133;
			break;
			case 133:
			addID = 135;
			break;
			case 135:
				addID = 137;
			break;
			case 137:
				addID = 229;
			break;

			case 2436: //Super attack
				addID = 145;
			break;
			case 145:
				addID = 147;
			break;
			case 147:
				addID = 149;
			break;
			case 149:
				addID = 229;
			break;

			case 2440: //Super strength
				addID = 157;
			break;
			case 157:
				addID = 159;
			break;
			case 159:
				addID = 161;
			break;
			case 161:
				addID = 229;
			break;

			case 2442: //Super defence
				addID = 163;
			break;
			case 163:
				addID = 165;
			break;
			case 165:
				addID = 167;
			break;
			case 167:
				addID = 229;
			break;

			case 2444: //Ranging
				addID = 169;
			break;
			case 169:
				addID = 171;
			break;
			case 171:
				addID = 173;
			break;
			case 173:
				addID = 229;
			break;

			case 3040: //Magic
				addID = 3042;
			break;
			case 3042:
				addID = 3044;
			break;
			case 3044:
				addID = 3046;
			break;
			case 3046:
				addID = 229;
			break;

			case 2434: //Prayer
				addID = 139;
			break;
			case 139:
				addID = 141;
			break;
			case 141:
				addID = 143;
			break;
			case 143:
				addID = 229;
			break;

			case 2430: //Restore
				addID = 127;
			break;
			case 127:
				addID = 129;
			break;
			case 129:
				addID = 131;
			break;
			case 131:
				addID = 229;
			break;

			case 3024: //Super restore
				addID = 3026;
			break;
			case 3026:
				addID = 3028;
			break;
			case 3028:
				addID = 3030;
			break;
			case 3030:
				addID = 229;
			break;

			case 6685: //Saradomin brew
				addID = 6687;
			break;
			case 6687:
				addID = 6689;
			break;
			case 6689:
				addID = 6691;
			break;
			case 6691:
				addID = 229;
			break;

			case 2450: //Zamorak brew
				addID = 189;
			break;
			case 189:
				addID = 191;
			break;
			case 191:
				addID = 193;
			break;
			case 193:
				addID = 229;
			break;

			//Food

			case 373:
			case 379:
			case 385:
			case 391:
			case 3144:
			case 7060:
			case 7946:
				addID = -1;
			break;

			//Teletabs

			case 8007: p.teletab("Varrock"); break;
			case 8008: p.teletab("Lumbridge"); break;
			case 8009: p.teletab("Falador"); break;
			case 8010: p.teletab("Camelot"); break;
			case 8011: p.teletab("Ardougne"); break;

			//Bones

			case 526: //Bones
				if (p.buryDelay <= 0) {
					Engine.playerItems.deleteItem(p, itemId, itemSlot, 1);
					p.requestAnim(827, 0);
					p.appendExperience(45, 5);
					p.buryDelay = 1;
				}
			break;
			case 536: //Dragon bones
				if (p.buryDelay <= 0) {
					Engine.playerItems.deleteItem(p, itemId, itemSlot, 1);
					p.requestAnim(827, 0);
					p.appendExperience(7200, 5);
					p.buryDelay = 2;
				}
			break;

		}

		//Deleting

		if (addID != -1 && addID != 0) {
			if (p.drinkDelay == 0) {
				Engine.playerItems.deleteItem(p, itemId, itemSlot, 1);
				Engine.playerItems.addItem(p, addID, 1);
				p.potion(itemId);
			}
		} else if (addID != 0) {
			if (itemId == 3144) {
				if (p.drinkDelay == 0) {
					Engine.playerItems.deleteItem(p, itemId, itemSlot, 1);
					p.food(itemId);
				}
			} else {
				if (p.eatDelay == 0 && p.drinkDelay == 0) {
					Engine.playerItems.deleteItem(p, itemId, itemSlot, 1);
					p.food(itemId);
				}
			}
		}

	} else {
		Misc.println("[" + p.username + "] Unhandled item select " + interfaceId + ":" + itemId);
	}
    }
}
