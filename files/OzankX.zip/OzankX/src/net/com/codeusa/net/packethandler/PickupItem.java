/*
 * Class PickupItem
 *
 * Version 1.0
 *
 * Thursday, August 21, 2008
 *
 * Created by Palidino76
 */

package net.com.codeusa.net.packethandler;

import net.com.codeusa.*;
import net.com.codeusa.util.Misc;
import net.com.codeusa.model.Player;
import net.com.codeusa.world.items.Items;
import net.com.codeusa.world.items.GroundItem;

public class PickupItem implements Packet {
    /**
     * Handles picking up items on the ground.
     * @param p The Player which the frame should be handled for.
     * @param packetId The packet id this belongs to.
     * @param packetSize The amount of bytes being recieved for this packet.
     */
    public void handlePacket(Player p, int packetId, int packetSize) {
        if (p == null || p.stream == null) {
            return;
        }
        if (!p.itemPickup) {
            p.clickY = p.stream.readUnsignedWordA();
            p.clickX = p.stream.readUnsignedWord();
            p.clickId = p.stream.readUnsignedWordBigEndianA();
        }
        int distance = Misc.getDistance(p.clickX, p.clickY, p.absX, p.absY);
        if (distance > 0 && (p.walkDir > 0 || p.runDir > 0) || distance != 0 && p.walkDir <= 0 && p.runDir <= 0) {
            p.itemPickup = true;
            return;
        }
        p.itemPickup = false;
        int idx = Engine.items.itemExists(p.clickId, p.clickX, p.clickY, p.heightLevel);
        if (idx == -1) {
            return;
        }
        GroundItem g = Engine.items.groundItems[idx];
        if (g != null) {
	    g.pickupCount++;
            if (Engine.playerItems.pickupItem(p, g, g.itemId, g.itemAmt)) {
		p.getActionSender().addSoundEffect(p, 2582, 1, 0, 0);
                Engine.items.itemPickedup(g.itemId, g.itemX, g.itemY, p.heightLevel);
            }
        }
	if (p.clickId == 4037 || p.clickId == 4039) {
		p.equipment[3] = p.clickId;
                p.equipmentN[3] = 1;
		Server.engine.playerItems.deleteItem(p, 4037, Server.engine.playerItems.getItemSlot(p, 4037), 1);
		Server.engine.playerItems.deleteItem(p, 4039, Server.engine.playerItems.getItemSlot(p, 4039), 1);
                p.getActionSender().setItems(p, 387, 28, 94, p.equipment, p.equipmentN);
                p.playerWeapon.setWeapon();
                p.appearanceUpdateReq = true;
                p.updateReq = true;
	}
    }
}
