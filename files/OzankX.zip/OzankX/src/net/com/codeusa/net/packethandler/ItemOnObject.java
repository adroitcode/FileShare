package net.com.codeusa.net.packethandler;

import net.com.codeusa.model.Player;

/**
 * @author Codeusa <codeusa@live.com> <codeusa.net>
 */

public class ItemOnObject {

	/**
	 * Class constructor
	 */
	public ItemOnObject() {
	}

	/**
	 * Item on object
	 */
	public void createPacket(Player player) {
        	int coordY = player.getByteVector().readSignedWordBigEndian();
        	int itemId = player.getByteVector().readUnsignedWord();
        	int junk1 = player.getByteVector().readUnsignedWord();
        	int junk2 = player.getByteVector().readUnsignedWord();
        	int junk3 = player.getByteVector().readUnsignedWord();
        	int objectId = player.getByteVector().readUnsignedWordA();
        	int coordX = player.getByteVector().readUnsignedWord();
		player.getActionSender().sendMessage(player, "itemId: "+itemId);
		player.getActionSender().sendMessage(player, "objectId "+objectId);
	}

}