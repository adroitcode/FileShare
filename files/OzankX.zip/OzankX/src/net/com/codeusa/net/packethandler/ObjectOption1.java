/*
 * Class ObjectOption1
 *
 * Version 2.0
 *
 * Friday, August 22, 2008
 *
 * Created by Codeusa info i re did the class because palis was shit.
 */

package net.com.codeusa.net.packethandler;

import net.com.codeusa.*;
import net.com.codeusa.model.misc.*;
import net.com.codeusa.model.Player;
import net.com.codeusa.model.skills.*;
import net.com.codeusa.model.games.*;
import net.com.codeusa.util.Misc;

public class ObjectOption1 implements Packet {
    /*
     * make sure to document EVERY coordinate to go with each object unless an un-important object(wilderness ditch lol).
     * This will prevent people from spawning an object client side and actually using it.
     * So make sure to include with the id, objectX == # && objectY == #
    */

    /**
     * Handles the first option on objects.
     * @param p The Player which the frame should be handled for.
     * @param packetId The packet id this belongs to.
     * @param packetSize The amount of bytes being recieved for this packet.
     */

    public void handlePacket(Player p, int packetId, int packetSize) {
        if (p == null || p.stream == null) {
            return;
        }
        if (!p.objectOption1) {
            p.clickX = p.stream.readUnsignedWordBigEndian();
            p.clickId = p.stream.readUnsignedWord();
            p.clickY = p.stream.readUnsignedWordBigEndianA();
            if (Misc.getDistance(p.absX, p.absY, p.clickX, p.clickY) > 3 && p.clickId != 26303) {
                return;
            }
            p.objectOption1 = true;
        }
        p.objectOption1 = false;
	PlayerMining playerMining = new PlayerMining(p);
	PlayerMethods pm = new PlayerMethods(p);
	FightCave fCave = new FightCave(p);
	System.out.println("x "+p.clickX+" y: "+p.clickY);
        switch (p.clickId) {

		case 1814: //Ardougne Lever
			p.leverTeleport("Deep Wilderness");
		break;
		case 1815: //Deep Wilderness
			p.leverTeleport("Ardougne Lever");
		break;
		case 5959: //Mage Bank (Outside)
			p.leverTeleport("Mage Bank (Inside)");
	        p.getActionSender().sendMessage(p, "Use the pool to use the bank.");			
		break;
		case 5960: //Mage Bank (Inside)
			p.leverTeleport("Mage Bank (Outside)");			
		break;
        case 9706:
		if (p.clickX == 3104 && p.clickY == 3956) {
        p.leverTeleport("Mage Arena (Inside)");
		}
        break;
		
		case 9707:
		if (p.clickX == 3105 && p.clickY == 3952) {
        p.leverTeleport("Mage Arena (Outside)");
		}
		break;
		//case 1816: //
		//break;
		//case 1817: //
		//break;
		
		case 2878:
		p.openBank();
		break;
		
		case 35543:
			if (p.absX == 3304 && p.absY == 3117 && p.heightLevel == 0) {
				p.setCoords(3304, 3115, 0);
			} else if (p.absX == 3304 && p.absY == 3115 && p.heightLevel == 0) {
				p.setCoords(3304, 3117, 0);
			}
		break;

		case 10529:
			if (p.absX == 3445 && p.absY == 3554 && p.heightLevel == 2)
				p.setCoords(3445, 3555, 2);
			else if (p.absX == 3445 && p.absY == 3555 && p.heightLevel == 2)
				p.setCoords(3445, 3554, 2);
		break;

		case 28214:
			p.blackTeam = false;
			p.whiteTeam = false;
			p.setCoords(3266 + Misc.random(3), 3683 + Misc.random(3), 0);
			p.getActionSender().sendMessage(p, "You stepped into the portal and left your clan mates.");
		break;

		case 28213:
			if (p.absX == 3270 && p.absY == 3675 || p.absX == 3271 && p.absY == 3675 || p.absX == 3272 && p.absY == 3675 ||
				p.absX == 3273 && p.absY == 3675) {
				p.whiteTeam = false;
				p.blackTeam = true;
				p.getActionSender().sendMessage(p, "Welcome to the Black clan.");
				p.getActionSender().sendMessage(p, "The game starts in " + Server.clanWaitDelay / 2 + " seconds.");
				p.getActionSender().sendMessage(p, "The game ends in " + Server.clanFightDelay / 2 + " seconds.");
			} else if (p.absX == 3271 && p.absY == 3692 || p.absX == 3272 && p.absY == 3692 || p.absX == 3273 && p.absY == 3692) {
				p.blackTeam = false;
				p.whiteTeam = true;
				p.getActionSender().sendMessage(p, "Welcome to the White clan.");
				p.getActionSender().sendMessage(p, "The game starts in " + Server.clanWaitDelay / 2 + " seconds.");
				p.getActionSender().sendMessage(p, "The game ends in " + Server.clanFightDelay / 2 + " seconds.");
			}
		break;

		case 14109:
			//p.setCoords(2449, 5178, 0);
			p.getActionSender().sendMessage(p, "Tzhaar is disabled for a few edits.");
		break;

		case 26293:
			p.getActionSender().sendMessage(p, "You've failed to climb up the rope.");
		break;

		case 23610:
			p.setCoords(3508, 9493, 0);
		break;

		case 9356:
			p.setCoords(2399, 5156, p.playerId * 4);
			p.waveDelay = 20;
			p.waveCount = 0;
		break;

		case 3831:
			p.setCoords(3483, 9509, 2);
		break;

		case 15116:
			p.setCoords(3227, 3103, 0);
		break;

		case 3829:
			p.setCoords(2509, 3847, 0);
		break;

		case 15647:
			if (p.absX == 2842 && p.absY == 3541 && p.heightLevel == 1)
				p.setCoords(2842, 3540, 1);
			else if (p.absX == 2842 && p.absY == 3540 && p.heightLevel == 1)
				p.setCoords(2842, 3541, 1);
		break;

		case 1530:
			if (p.absX == 2838 && p.absY == 3539 && p.heightLevel == 1)
				p.setCoords(2838, 3538, 1);
			else if (p.absX == 2838 && p.absY == 3538 && p.heightLevel == 1)
				p.setCoords(2838, 3539, 1);
		break;

		case 1738:
			if (p.absX == 2841 && p.absY == 3538 && p.heightLevel == 0)
				p.setCoords(2840, 3539, 1);
			else if (p.absX == 2840 && p.absY == 3539 && p.heightLevel == 2)
				p.setCoords(2841, 3538, 0);
		break;

		case 15644:
			if (p.absX == 2855 && p.absY == 3546 && p.heightLevel == 0)
				p.setCoords(2855, 3545, 0);
			else if (p.absX == 2855 && p.absY == 3545 && p.heightLevel == 0)
				p.setCoords(2855, 3546, 0);
			//Height 2
			if (p.absX == 2846 && p.absY == 3541 && p.heightLevel == 2) {
				if (Server.engine.playerItems.hasPlayerItemAmount(p, 8851, 100))
					p.setCoords(2847, 3541, 2);
				else
					p.getActionSender().sendMessage(p, "You need atleast 100 Warrior guild tokens to enter.");
			}
			if (p.absX == 2847 && p.absY == 3541 && p.heightLevel == 2)
				p.setCoords(2846, 3541, 2);
          		Misc.println("[" + p.username + "] Unhandled object 1: " + p.clickId);
		break;

		case 15641:
			if (p.absX == 2854 && p.absY == 3546 && p.heightLevel == 0)
				p.setCoords(2854, 3545, 0);
			else if (p.absX == 2854 && p.absY == 3545 && p.heightLevel == 0)
				p.setCoords(2854, 3546, 0);
			//Height 2
			if (p.absX == 2846 && p.absY == 3540 && p.heightLevel == 2) {
				if (Server.engine.playerItems.hasPlayerItemAmount(p, 8851, 100))
					p.setCoords(2847, 3540, 2);
				else
					p.getActionSender().sendMessage(p, "You need atleast 100 Warrior guild tokens to enter.");
			}
			if (p.absX == 2847 && p.absY == 3540 && p.heightLevel == 2)
				p.setCoords(2846, 3540, 2);
          		Misc.println("[" + p.username + "] Unhandled object 1: " + p.clickId);
		break;

		case 3832:
			p.setCoords(3483, 9509, 2);
		break;

		case 9368:
			if (p.rights >= 1) {
				if (p.absX == 2399 && p.absY == 5169 && p.heightLevel == 0) {
					p.setCoords(2399, 5167, fCave.getCaveHeight());
					p.getActionSender().sendMessage(p, "You enter the Fight Cave.");
					p.waveDelay = 20;
				} else if (p.absX == 2399 && p.absY == 5167) {
					p.setCoords(2399, 5169, 0);
					p.getActionSender().sendMessage(p, "You leave the Fight Cave.");
				}
			} else {
				p.getActionSender().sendMessage(p, "Sorry, This feature is moderator+ only.");
			}
		break;



		/**
		 * Enter Bandos stronghold	
	 	 */
		case 26384:
			if (p.getLevelForXP(2) > 69) {
				if (p.absX == 2851 && p.absY == 5333) {
					p.setCoords(2850, 5333, 2);
				} else if (p.absX == 2850 && p.absY == 5333) {
					p.setCoords(2851, 5333, 2);
				}
			} else {	
				p.getActionSender().sendMessage(p, "You need a Strength level of 70 to enter Bandos's Stronghold.");
			}
		break;

		/**
		 * Enter saradomin part
		 */
		case 26444:
			if (p.absX == 2912 && p.absY == 5300) {
				p.setCoords(2914, 5300, 1);
			}
		break;

		/**
		 * Enter saradomin part 2
		 */
		case 26445:
			if (p.absX == 2920 && p.absY == 5276) {
				p.setCoords(2920, 5274, 0);
			}
		break;

		case 26427:
			if (p.absX == 2908 && p.absY == 5265) {
				p.setCoords(2907, 5265, 0);
			} else if (p.absX == 2907 && p.absY == 5265) {
				p.setCoords(2908, 5265, 0);
			}
		break;

		/**
		 * Enter Tsusaroth's chamber
		 */
		case 26428:
			if (p.absX == 2925 && p.absY == 5332) {
				if (p.godWarsKills[3] >= 10)
					p.setCoords(2925, 5331, 2);
				else
					p.getActionSender().sendMessage(p, "You need atleast 10 Zamorak kills to enter this chamber.");
			}
			if (p.absX == 2925 && p.absY == 5331) {
				p.setCoords(2925, 5332, 2);
			}
			p.getActionSender().setOverlay(p, 598);
		break;

		/**
		 * Enter/Exit Zamorak's fortress.
		 */
		case 26439:
			if (p.skillLvl[3] > 69) {
				if (p.absX == 2885 && p.absY == 5345) {
					p.getActionSender().setOverlay(p, 601);	
					p.setCoords(2885, 5332, 2);
				} else	if (p.absX == 2885 && p.absY == 5332) {
					p.getActionSender().setOverlay(p, 598);
					p.setCoords(2885, 5345, 2);
				}
			} else {
				p.getActionSender().sendMessage(p, "You need atleast a hitpoint level of 70 to climb off the bridge.");
			}
		break;

		/**
		 * Enter/Exit Armadyl's Eyrie.
		 */
		case 26303:
			if (p.equipment[3] == 9185) {
				if (p.skillLvl[4] > 69) {
					if (Misc.getDistance(p.absX, p.absY, p.clickX, p.clickY) <= 11) {
						if (p.absX == 2871 && p.absY == 5269) {
							p.setCoords(2872, 5279, 2);
							p.getActionSender().sendMessage(p, "You leave Armadyl's Eyrie.");
						} else {
							p.setCoords(2871, 5269, 2);
							p.getActionSender().sendMessage(p, "You enter Armadyl's Eyrie.");
						}
					
					}
				} else {
					p.getActionSender().sendMessage(p, "You need a ranged level of 70 to enter Armadyl's Eyrie.");
				}
			} else {
				p.getActionSender().sendMessage(p, "You need a runite crossbow to enter Armadyl's Eyrie.");
			}
		break;

		case 2213:
		case 2693:
		case 4483:
		case 11402:
		case 36786:
                case 26972:
			p.openBank();
		break;

		case 36776:
			p.setCoords(p.absX, p.absY, 2);
		break;

		case 36778:
			p.setCoords(p.absX, p.absY, 0);
		break;

		/**
		 * Mage arena
		 */

		case 733:
			if (p.clickX == 3095 && p.clickY == 3957) {
				if (p.absX == 3095 && p.absY == 3957)
					p.setCoords(3094, 3957, 0);
				else
					p.setCoords(3095, 3957, 0);
			}
			if (p.clickX == 3092 && p.clickY == 3957) {
				if (p.absX == 3093 && p.absY == 3957)
					p.setCoords(3092, 3957, 0);
				else
					p.setCoords(3093, 3957, 0);
			}
			if (p.clickX == (3105) && p.clickY == 3958 || p.clickX == (3106) && p.clickY == 3958) {
				if (p.absX == 3105 && p.absY == 3959 || p.absX == 3106 && p.absY == 3959)
					p.setCoords(3105, 3957, 0);
				else
					p.setCoords(3105, 3959, 0);			
			}
		break;

		/**
		 * God wars
		 */
		case 26425:
			/**
			 * Bandos door
			 */
			if (!p.graardorChamber()) {
				p.setCoords(2865, 5354, 2);
			} else {
				p.setCoords(2863, 5354, 2);
			}
		break;

		case 26426:
			if (!p.armadylChamber()) {
				if (p.godWarsKills[0] >= 2)
					p.setCoords(2839, 5296, 2);
				else
					p.getActionSender().sendMessage(p, "You atleast need 2 Armadyl kills to enter this Chamber.");
			} else {
				p.setCoords(2839, 5295, 2);
			}
		break;

		case 28140:
			p.setCoords(3266 + Misc.random(2), 3692 + Misc.random(2), 0);
		break;

		case 23271:
			if (p.freezeDelay > 0) break;
			p.crossDitch();
		break;

		case 26289:
		case 26288:
		case 24343:
		case 27661:
			if (p.skillLvl[5] != p.getLevelForXP(5)) {
				p.requestAnim(645, 0);
				p.skillLvl[5] = p.getLevelForXP(5);
				p.getActionSender().sendMessage(p, "You restore your prayer points.");
			} else {
				p.getActionSender().sendMessage(p, "Your prayer points are still full.");
			}
			p.getActionSender().setSkillLvl(p, 5);
			p.appearanceUpdateReq = true;
			p.updateReq = true;
		break;

        case 6552:
            if (p.spellbook == 193) {
                p.questStage = 3;
                p.spellbook = 192;
                p.getActionSender().setTab(p, 79, p.spellbook);
                p.message("You feel a strange drain upon your memory.");
                p.requestAnim(811, 0);
				p.requestGFX(308, 0);
				} else {
					if (p.getLevelForXP(6) < 50) {
						p.message("You need 50 Magic to switch to Ancients Magicks.");
						return;
					}
			    p.spellbook = 193;
			    p.requestAnim(1979, 0);
			    p.requestGFX(369, 0);		
			    p.getActionSender().setTab(p, 79, p.spellbook);
			    p.message("You feel a strange wisdom fill your mind...");
		}
		break;

        case 17010:
		    if (p.spellbook == 430) {
			    p.questStage = 3;
			    p.requestAnim(811, 0);
			    p.requestGFX(308, 0);
			    p.spellbook = 192;
			    p.getActionSender().setTab(p, 79, p.spellbook);
		    } else {
					if (p.getLevelForXP(1) < 40) {
						p.message("You need 40 Defence to switch to the Lunar Spellbook.");
						return;
					}
			    p.spellbook = 430;
			    p.requestAnim(6299, 0);
			    p.requestGFX(1062, 0);
			    p.getActionSender().setTab(p, 79, p.spellbook);
		}
		break;


        case 2475:
        p.teleportTo(3093 + Misc.random(1), 3490 + Misc.random(1), 0, 4, 0, 8939, 8941, 1576, 0, 1577, 0);
        break;

		case 28119:
		case 28120:
		case 28121:
			p.setCoords(3152 + Misc.random(6), 3710 + Misc.random(6), 0);
			p.getActionSender().sendMessage(p, "You enter the pk arena.");
		break;

		case 28122:
		case 28123:
		case 28124:
			p.setCoords(3170 + Misc.random(3), 3676 + Misc.random(3), 0);
			p.getActionSender().sendMessage(p, "You leave the pk arena.");
		break;

        default:
            Misc.println("[" + p.username + "] Unhandled object 1: " + p.clickId);
            break;
        }
    }

    private int objectSize(int id) {
        switch (id) {
        default:
            return 1;
        }
    }
}
