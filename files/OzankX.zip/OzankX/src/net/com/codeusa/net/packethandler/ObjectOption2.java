/*
 * Class ObjectOption1
 *
 * Version 1.0
 *
 * Saturday, August 23, 2008
 *
 * Created by Palidino76
 */

package net.com.codeusa.net.packethandler;

import net.com.codeusa.model.Player;
import net.com.codeusa.util.Misc;

public class ObjectOption2 implements Packet {
    /*
     * make sure to document EVERY coordinate to go with each object unless an un-important object(wilderness ditch lol).
     * This will prevent people from spawning an object client side and actually using it.
     * So make sure to include with the id, objectX == # && objectY == #
    */

    /**
     * Handles the second option on objects.
     * @param p The Player which the frame should be handled for.
     * @param packetId The packet id this belongs to.
     * @param packetSize The amount of bytes being recieved for this packet.
     */
    public void handlePacket(Player p, int packetId, int packetSize) {
        if (p == null || p.stream == null) {
            return;
        }
        if (!p.objectOption2) {
            p.clickY = p.stream.readUnsignedWordA();
            p.clickId = p.stream.readUnsignedWordBigEndian();
            p.clickX = p.stream.readUnsignedWordBigEndianA();
            if (Misc.getDistance(p.absX, p.absY, p.clickX, p.clickY) > 30) {
                return;
            }
            p.objectOption2 = true;
        }
        int distance = Misc.getDistance(p.clickX, p.clickY, p.absX, p.absY);
        if (p.walkDir != -1 || p.runDir != -1 || distance > objectSize(p.clickId)) {
            return;
        }
        p.objectOption2 = false;
	if (p.clickId == 4705) {
		p.thievingArray[2] = p.skillLvl[17];
		if (p.thievingArray[3] > 0)
			return;
	}
        switch (p.clickId) {

		case 4705:
			p.thievingArray[1] = 1;
			p.requestAnim(833, 0);
			p.getActionSender().sendMessage(p, "You attempt to steal something..");
			p.thievingArray[3] = 1;
			p.thievingArray[0] = 1;
		break;

		case 4706:
			p.thievingArray[1] = 2;
			p.requestAnim(833, 0);
			p.getActionSender().sendMessage(p, "You attempt to steal something..");
			p.thievingArray[3] = 1;
			p.thievingArray[0] = 1;
		break;

		case 28716:
			if (p.skillLvl[23] != p.getLevelForXP(23)) {
				p.requestAnim(645, 0);
				p.skillLvl[23] = p.getLevelForXP(23);
				p.getActionSender().setSkillLvl(p, 23);
				p.getActionSender().sendMessage(p, "You restore your summoning skill points.");
			} else {
				p.getActionSender().sendMessage(p, "Your summoning skill points are full already.");
			}
		break;

		case 2213:
		case 11402:
		case 36786:
		case 27663:
		case 26972:
		case 11758:
		case 25808:
		case 34752:
			p.openBank();
		break;

                case 17010:
		if (p.spellbook == 430 || p.spellbook == 193) {
			p.questStage = 3;
			p.message("You feel a strange drain upon your memory...");
			p.requestAnim(6299, 0);
			p.requestGFX(1062, 0);
			p.spellbook = 192;
			p.getActionSender().setTab(p, 79, p.spellbook);
		} else {
					if (p.getLevelForXP(1) < 40) {
						p.message("You need 40 Defence to switch to the Lunar Spellbook.");
						return;
					}
			p.spellbook = 430;
			p.requestAnim(6299, 0);
			p.requestGFX(1062, 0);
			p.getActionSender().setTab(p, 79, p.spellbook);
			p.message("You feel the moon's power as you switch to the Lunar Spellbook...");
		}
		break;

		case 36956:
			p.getActionSender().setInterface(p, 0, 548, 8, 311);
		break;
        default:
            Misc.println("[" + p.username + "] Unhandled object 2: " + p.clickId);
            break;
        }
    }

    private int objectSize(int id) {
        switch (id) {
        default:
            return 1;
        }
    }
}
