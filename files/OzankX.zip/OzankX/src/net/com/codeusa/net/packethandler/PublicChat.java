/*
 * Class PublicChat
 *
 * Version 1.0
 *
 * Sunday, August 17, 2008
 *
 * Created by Codeusa palis was crap i re did it
 */

package net.com.codeusa.net.packethandler;

import net.com.codeusa.Server;
import net.com.codeusa.model.Player;
import net.com.codeusa.util.Misc;

public class PublicChat implements Packet {
    /**
     * Handles player chatting.
     * @param p The Player which the frame should be handled for.
     * @param packetId The packet id this belongs to.
     * @param packetSize The amount of bytes being recieved for this packet.
     */
    public void handlePacket(Player p, int packetId, int packetSize) {
        if (p == null || p.stream == null) {
            return;
        }
        p.chatTextEffects = p.stream.readUnsignedWord();
        int numChars = p.stream.readUnsignedByte();
        p.chatText = Misc.decryptPlayerChat(p.stream, numChars);
	if (p.muteType > 0) {
		p.getActionSender().sendMessage(p, "You have been muted and cannot talk.");
		return;
	}
	if (p.chatText.startsWith("/")) {
		try {
			String chat = p.activeChat;
			for (Player player : Server.engine.players) {
				if (player != null) {
					if (player.activeChatOwner.equals(p.activeChatOwner)) {
						if (p.rights == 0) {
							player.getActionSender().sendMessage(player, "[<col=0000ff>"+chat+"</col>] "+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+": <col=880000>"+p.chatText.substring(1) + ":clan:");
						} else if (p.rights == 1) {
							player.getActionSender().sendMessage(player, "[<col=0000ff>"+chat+"</col>] <img=0>"+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+": <col=880000>"+p.chatText.substring(1) +":clan:");
						} else if (p.rights == 2) {
							player.getActionSender().sendMessage(player, "[<col=0000ff>"+chat+"</col>] <img=1>"+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+": <col=880000>"+p.chatText.substring(1) +":clan:");
						} else if (p.rights >= 3) {
							player.getActionSender().sendMessage(player, "[<col=0000ff>"+chat+"</col>] "+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+": <col=880000>"+p.chatText.substring(1) + ":clan:");
						}
					}
				}
			}
		} catch (Exception e) {
			return;
		}
		return;
	}
        p.chatTextUpdateReq = true;
        p.updateReq = true;
    }
}
