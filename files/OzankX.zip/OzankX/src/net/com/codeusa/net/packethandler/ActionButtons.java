/*
 * Class ActionButtons
 *
 * Version 1.0
 *
 * Monday, August 18, 2008
 *
 * Created by Palidino76 Edited by Codeusa
 */

package net.com.codeusa.net.packethandler;

import net.com.codeusa.*;
import net.com.codeusa.model.quest.*;
import net.com.codeusa.model.games.*;
import net.com.codeusa.model.combat.*;
import net.com.codeusa.model.Player;
import net.com.codeusa.util.Misc;

public class ActionButtons implements Packet {
    /**
     * Handles buttons on interfaces.
     * @param p The Player which the frame should be handled for.
     * @param packetId The packet id this belongs to.
     * @param packetSize The amount of bytes being recieved for this packet.
     */

	public int color = 1; //Used for clothes stuff

    public void handlePacket(Player p, int packetId, int packetSize) {
        if (p == null || p.stream == null) {
            return;
        }
        int interfaceId = p.stream.readUnsignedWord();
        int buttonId = p.stream.readUnsignedWord();
        int buttonId2 = 0;
        if (packetId == 233 || packetId == 21 || packetId == 169 || packetId == 232) {
            buttonId2 = p.stream.readUnsignedWord();
        }
        if (buttonId2 == 65535) {
            buttonId2 = 0;
        }
	int warriorLevel = p.getLevelForXP(0) + p.getLevelForXP(2);
	QuestDevelopment quest = new QuestDevelopment(p);
	FightCave fCave = new FightCave(p);
	DuelArena duelArena = new DuelArena(p);
        switch (interfaceId) {

	case 523:
		if (buttonId == 100) {
			p.getActionSender().setTab(p, 79, p.spellbook);
		}
	break;
case 378:
	if (buttonId == 140) {
		p.getActionSender().setWindowPane(p, 548);
	}
break;
	case 259:
		if (buttonId == 2) {
			quest.addQuestScroll();
			quest.setQuestId(1);
		}
	break;

case 591:
p.appearanceUpdateReq = true;
p.updateReq = true;
switch(buttonId) {

case 182:
color = 1;
break;

case 183:
color = 1;
break;

case 184:
color = 2;
break;

case 180:
p.getActionSender().removeShownInterface(p);
color = 1;
break;

//start torsos
case 185:
p.look[2] = 111;
break;
case 186:
p.look[2] = 116;
break;
case 187:
p.look[2] = 114;
break;
case 188:
p.look[2] = 115;
break;
case 189:
p.look[2] = 112;
break;
case 190:
p.look[2] = 113;
break;
case 191:
p.look[2] = 18;
break;
case 192:
p.look[2] = 19;
break;
case 193:
p.look[2] = 20;
break;
case 194:
p.look[2] = 21;
break;
case 195:
p.look[2] = 22;
break;
case 196:
p.look[2] = 23;
break;
case 197:
p.look[2] = 24;
break;
case 198:
p.look[2] = 25;
break;
//end torsos

//start sleeves
case 199:
p.look[3] = 105;
break;
case 200:
p.look[3] = 108;
break;
case 201:
p.look[3] = 107;
break;
case 202:
p.look[3] = 106;
break;
case 203:
p.look[3] = 109;
break;
case 204:
p.look[3] = 110;
break;
case 205:
p.look[3] = 28;
break;
case 206:
p.look[3] = 26;
break;
case 207:
p.look[3] = 27;
break;
case 208:
p.look[3] = 29;
break;
case 209:
p.look[3] = 30;
break;
case 210:
p.look[3] = 31;
break;
//end sleeves

//start legs
case 211:
p.look[5] = 36;
break;
case 212:
p.look[5] = 85;
break;
case 213:
p.look[5] = 37;
break;
case 214:
p.look[5] = 41;
break;
case 215:
p.look[5] = 89;
break;
case 216:
p.look[5] = 90;
break;
case 217:
p.look[5] = 39;
break;
case 218:
p.look[5] = 88;
break;
case 219:
p.look[5] = 87;
break;
case 220:
p.look[5] = 38;
break;
case 221:
p.look[5] = 86;
break;

case 280://black
p.color[color] = 16;
break;
case 279://dark grey
p.color[color] = color;
break;
case 278://taupe
p.color[color] = 17;
break;
case 277://light grey
p.color[color] = 18;
break;
case 276://beige
p.color[color] = color + 4;
break;
case 275://navy blue
p.color[color] = color + 2;
break;
case 274://indigo
p.color[color] = 27;
break;
case 273://violet
p.color[color] = 28;
break;
case 272://mauve
p.color[color] = color + 9;
break;
case 270://light blue
p.color[color] = 20;
break;
case 271://pale blue
p.color[color] = color + 13;
break;
case 269://dark blue
p.color[color] = color + 6;
break;
case 268://royal blue
p.color[color] = 21;
break;
case 267://dark green
p.color[color] = 26;
break;
case 266://forest green
p.color[color] = color == 2 ? 0 : 15;
break;
case 265://sea green
p.color[color] = color + 7;
break;
case 264://mint green
p.color[color] = 25;
break;
case 263://moss green
p.color[color] = color + 12;
break;
case 262://gold
p.color[color] = color + 8;
break;

case 281:
color = 1;
break;

default:
Misc.println("Unhandled char screen button: "  + buttonId + ":" + buttonId2);
break;
}
break;




case 592:
p.appearanceUpdateReq = true;
p.updateReq = true;
if(buttonId == 168) {//bald
p.look[0] = 45;
}
if(buttonId == 169) {//bun
p.look[0] = 46;
}
if(buttonId == 170) {//dreadlocks
p.look[0] = 47;
}
if(buttonId == 171) {//long
p.look[0] = 48;
}
if(buttonId == 172) {//short
p.look[0] = 49;
}
if(buttonId == 173) {//pigtails
p.look[0] = 50;
}
if(buttonId == 174) {//crew cut
p.look[0] = 51;
}
if(buttonId == 175) {//close cropped
p.look[0] = 52;
}
if(buttonId == 176) {//wild spikes
p.look[0] = 53;
}
if(buttonId == 177) {//spikes
p.look[0] = 54;
}
if(buttonId == 178) {
p.look[0] = 135;
}
if(buttonId == 179) {
p.look[0] = 136;
}
if(buttonId == 180) {
p.look[0] = 137;
}
if(buttonId == 181) {
p.look[0] = 138;
}
if(buttonId == 182) {
p.look[0] = 139;
}
if(buttonId == 183) {
p.look[0] = 140;
}
if(buttonId == 184) {
p.look[0] = 141;
}
if(buttonId == 185) {
p.look[0] = 142;
}
if(buttonId == 186) {
p.look[0] = 143;
}
if(buttonId == 187) {
p.look[0] = 144;
}
break;



case 596:
if(buttonId == 245) {
p.color[0] = 1;
}
if(buttonId == 228) {
p.color[0] = 4;
}
if(buttonId == 229) {
p.color[0] = 5;
}
if(buttonId == 233) {
p.color[0] = 6;
}
if(buttonId == 231) {
p.color[0] = 7;
}
if(buttonId == 235) {
p.color[0] = 9;
}
if(buttonId == 226) {
p.color[0] = 10;
}
if(buttonId == 240) {
p.color[0] = 11;
}
if(buttonId == 243) {
p.color[0] = 3;
}
if(buttonId == 247) {
p.color[0] = 13;
}
if(buttonId == 230) {
p.color[0] = 15;
}
if(buttonId == 239) {
p.color[0] = 16;
}
if(buttonId == 227) {
p.color[0] = 18;
}
if(buttonId == 225) {
p.color[0] = 19;
}
if(buttonId == 224) {
p.color[0] = 20;
}
if(buttonId == 234) {
p.color[0] = 21;
}
if(buttonId == 236) {
p.color[0] = 22;
}
if(buttonId == 242) {
p.color[0] = 23;
}
if(buttonId == 241) {
p.color[0] = 24;
}
if(buttonId == 232) {
p.color[0] = 25;
}
if(buttonId == 237) {
p.color[0] = 17;
}
if(buttonId == 246) {
p.color[0] = 14;
}
if(buttonId == 244) {
p.color[0] = 2;
}
if(buttonId == 248) {
p.color[0] = 12;
}
if(buttonId == 238) {
p.color[0] = 8;
}
if(buttonId == 160) {
p.getActionSender().removeShownInterface(p);
}
if(buttonId == 167) {//bald
p.look[0] = 0;
}
if(buttonId == 168) {//dreadlocks
p.look[0] = 1;
}
if(buttonId == 169) {//long hair
p.look[0] = 2;
}
if(buttonId == 170) {//long hair
p.look[0] = 3;
}
if(buttonId == 171) {//crew cut
p.look[0] = 4;
}
if(buttonId == 172) {//crew cut
p.look[0] = 5;
}
if(buttonId == 173) {//crew cut
p.look[0] = 6;
}
if(buttonId == 174) {//Wild spikes
p.look[0] = 7;
}
if(buttonId == 175) {//Spikes
p.look[0] = 8;
}
if(buttonId == 176) {//Mohawk
p.look[0] = 91;
}
if(buttonId == 177) {
p.look[0] = 92;
}
if(buttonId == 178) {
p.look[0] = 93;
}
if(buttonId == 179) {
p.look[0] = 94;
}
if(buttonId == 180) {
p.look[0] = 95;
}
if(buttonId == 181) {
p.look[0] = 96;
}
if(buttonId == 182) {
p.look[0] = 97;
}
if(buttonId == 183) { //Goatee
p.look[1] = 10;
}
if(buttonId == 184) { //Long Beard
p.look[1] = 11;
}
if(buttonId == 185) { //Med Beard
p.look[1] = 12;
}
if(buttonId == 186) { //Mustouche
p.look[1] = 13;
}
if(buttonId == 187) { //Clean Shaven
p.look[1] = 14;
}
if(buttonId == 188) { //Short Beard
p.look[1] = 15;
}
if(buttonId == 189) { //Short Full
p.look[1] = 16;
}
if(buttonId == 190) { //Split
p.look[1] = 17;
}
if(buttonId == 191) { //Handle Bar 
p.look[1] = 98;
}
if(buttonId == 192) { //Mutton
p.look[1] = 99;
}
if(buttonId == 193) { //Full Mutton
p.look[1] = 100;
}
if(buttonId == 194) { //Full Mustouche
p.look[1] = 101;
}
if(buttonId == 195) { //Waxed
p.look[1] = 102;
}
if(buttonId == 196) { //Dali
p.look[1] = 103;
}
if(buttonId == 197) { //Visier
p.look[1] = 104;
}
else if(buttonId != 160 || buttonId !=167 || buttonId !=168 || buttonId !=169 || buttonId !=170 || buttonId !=171 || buttonId !=172 || buttonId !=173 || buttonId !=174 || buttonId !=175 || buttonId !=176 || buttonId !=177 || buttonId !=178 || buttonId !=179 || buttonId !=180 || buttonId !=181 || buttonId !=182) {
Misc.println("Unhandled hair button: "  + buttonId);
}
p.appearanceUpdateReq = true;
p.updateReq = true;

break;
	case 662:
		/**
		 * Summoning IDS
		 */
		if (buttonId == 50) {
			if (p.summonedFamiliar)
				Server.engine.rebuildNPCs();
			if (p.summonedFamiliar)
				p.callFamiliar = true;
		}
		if (buttonId == 52) {
			if (p.summonedFamiliar)
				p.familiarDissMiss = true;
		}
	break;
        case 387:
            /*
             * Equipment tab.
             */
            if (buttonId == 55) {
                p.setEquipmentBonus();
                p.getActionSender().showInterface(p, 667);
                p.getActionSender().setInventory(p, 149);
                p.getActionSender().setItems(p, -1327, 64209, 93, p.items, p.itemsN);
                p.getActionSender().setItems(p, -1328, 64208, 94, p.equipment, p.equipmentN);
            }
            break;

	case 271:
		int prayer = -1;
		String name = "";
		if (buttonId == 5) { //Thick Skin
			prayer = 0;
			name = "Thick Skin";
			if (!p.usingPrayer(prayer)) p.switchPrayers(new int[] {5, 13, 25, 26}, prayer);
		}
		if (buttonId == 5) { //Thick Skin
			prayer = 0;
			name = "Thick Skin";
			if (!p.usingPrayer(prayer)) p.switchPrayers(new int[] {5, 13, 25, 26}, prayer);
		}
		if (buttonId == 7) { //Burst of Strength
			prayer = 1;
			name = "Burst of Strength";
			if (!p.usingPrayer(prayer)) p.switchPrayers(new int[] {3, 4, 6, 11, 12, 14, 20, 21, 25, 26}, prayer);
		}
		if (buttonId == 9) { //Clarity of Thought
			prayer = 2;
			name = "Clarity of Thought";
			if (!p.usingPrayer(prayer)) p.switchPrayers(new int[] {3, 4, 7, 11, 12, 15, 20, 21, 25, 26}, prayer);
		}
		if (buttonId == 11) { //Sharp Eye
			prayer = 3;
			name = "Sharp Eye";
			if (!p.usingPrayer(prayer)) p.switchPrayers(new int[] {1, 2, 4, 6, 7, 11, 12, 14, 15, 20, 21, 25, 26}, prayer);
		}
		if (buttonId == 13) { //Mystic Will
			prayer = 4;
			name = "Mystic Will";
			if (!p.usingPrayer(prayer)) p.switchPrayers(new int[] {1, 2, 3, 6, 7, 11, 12, 14, 15, 20, 21, 25, 26}, prayer);
		}
		if (buttonId == 15) { //Rock Skin
			prayer = 5;
			name = "Rock Skin";
			if (!p.usingPrayer(prayer)) p.switchPrayers(new int[] {0, 13, 25, 26}, prayer);
		}
		if (buttonId == 17) { //Superhuman Strength
			prayer = 6;
			name = "Superhuman Strength";
			if (!p.usingPrayer(prayer)) p.switchPrayers(new int[] {1, 3, 4, 11, 12, 14, 20, 21, 25, 26}, prayer);
		}
		if (buttonId == 19) { //Improved Reflexes
			prayer = 7;
			name= "Improved Reflexes";
			if (!p.usingPrayer(prayer)) p.switchPrayers(new int[] {2, 3, 4, 11, 12, 15, 20, 21, 25, 26}, prayer);
		}
		if (buttonId == 21) { //Rapid Restore
			prayer = 8;
			name = "Rapid Restore";
		}
		if (buttonId == 23) { //Rapid Heal
			prayer = 9;
			name = "Rapid Heal";
		}
		if (buttonId == 25) { //Protect Item
			prayer = 10;
			name = "Protect Item";
		}
		if (buttonId == 27) { //Hawk Eye
			prayer = 11;
			name = "Hawk Eye";
			if (!p.usingPrayer(prayer)) p.switchPrayers(new int[] {1, 2, 3, 4, 6, 7, 12, 14, 15, 20, 21, 25, 26}, prayer);
		}
		if (buttonId == 29) { //Mystic Lore
			prayer = 12;
			name = "Mystic Lore";
			if (!p.usingPrayer(prayer)) p.switchPrayers(new int[] {1, 2, 3, 4, 6, 7, 11, 14, 15, 20, 21, 25, 26}, prayer);
		}
		if (buttonId == 31) { //Steel Skin
			prayer = 13;
			name = "Steel Skin";
			if (!p.usingPrayer(prayer)) p.switchPrayers(new int[] {0, 5, 25, 26}, prayer);
		}
		if (buttonId == 33) { //Ultimate Strength
			prayer = 14;
			name = "Ultimate Strength";
			if (!p.usingPrayer(prayer)) p.switchPrayers(new int[] {1, 3, 4, 6, 11, 12, 20, 21, 25, 26}, prayer);
		}
		if (buttonId == 35) { //Incredible Reflexes
			prayer = 15;
			name = "Incredible Reflexes";
			if (!p.usingPrayer(prayer)) p.switchPrayers(new int[] {2, 3, 4, 7, 11, 12, 20, 21, 25, 26}, prayer);
		}
		if (buttonId == 53) { //Protect from Summoning
			prayer = 16;
			name = "Protect from Summoning";
			if (!p.usingPrayer(prayer)) {
				p.switchPrayers(new int[] {22, 23, 24}, prayer);
				if (p.usingPrayer(17)) {
					p.headIconPrayer = 10;
				} else if (p.usingPrayer(18)) {
					p.headIconPrayer = 9;
				} else if (p.usingPrayer(19)) {
					p.headIconPrayer = 8;
				} else {
					p.headIconPrayer = 7;
				}
			} else {
				if (p.usingPrayer(17)) {
					p.headIconPrayer = 2;
				} else if (p.usingPrayer(18)) {
					p.headIconPrayer = 1;
				} else if (p.usingPrayer(19)) {
					p.headIconPrayer = 0;
				} else {
					p.headIconPrayer = -1;
				}
			}
		}
		if (buttonId == 37) { //Protect from Magic
			prayer = 17;
			name = "Protect from Magic";
			if (!p.usingPrayer(prayer)) {
				p.switchPrayers(new int[] {18, 19, 22, 23, 24}, prayer);
				if (p.usingPrayer(16)) {
					p.headIconPrayer = 10;
				} else {
					p.headIconPrayer = 2;
				}
			} else {
				if (p.usingPrayer(16)) {
					p.headIconPrayer = 7;
				} else {
					p.headIconPrayer = -1;
				}
			}
		}
		if (buttonId == 39) { //Protect from Missiles
			prayer = 18;
			name = "Protect from Missiles";
			if (!p.usingPrayer(prayer)) {
				p.switchPrayers(new int[] {17, 19, 22, 23, 24}, prayer);
				if (p.usingPrayer(16)) {
					p.headIconPrayer = 9;
				} else {
					p.headIconPrayer = 1;
				}
			} else {
				if (p.usingPrayer(16)) {
					p.headIconPrayer = 7;
				} else {
					p.headIconPrayer = -1;
				}
			}
		}
		if (buttonId == 41) { //Protect from Melee
			prayer = 19;
			name = "Protect from Melee";
			if (!p.usingPrayer(prayer)) {
				p.switchPrayers(new int[] {17, 18, 22, 23, 24}, prayer);
				if (p.usingPrayer(16)) {
					p.headIconPrayer = 8;
				} else {
					p.headIconPrayer = 0;
				}
			} else {
				if (p.usingPrayer(16)) {
					p.headIconPrayer = 7;
				} else {
					p.headIconPrayer = -1;
				}
			}
		}
		if (buttonId == 43) { //Eagle Eye
			prayer = 20;
			name = "Eagle Eye";
			if (!p.usingPrayer(prayer)) p.switchPrayers(new int[] {1, 2, 3, 4, 6, 7, 11, 12, 14, 15, 21, 25, 26}, prayer);
		}
		if (buttonId == 45) { //Mystic Might
			prayer = 21;
			name = "Mystic Might";
			if (!p.usingPrayer(prayer)) p.switchPrayers(new int[] {1, 2, 3, 4, 6, 7, 11, 12, 14, 15, 20, 25, 26}, prayer);
		}
		if (buttonId == 47) { //Retribution
			prayer = 22;
			name = "Retribution";
			if (!p.usingPrayer(prayer)) {
				p.switchPrayers(new int[] {16, 17, 18, 19, 23, 24}, prayer);
				p.headIconPrayer = 3;
			} else {
				p.headIconPrayer = -1;
			}
		}
		if (buttonId == 49) { //Redemption
			prayer = 23;
			name = "Redemption";
			if (!p.usingPrayer(prayer)) {
				p.switchPrayers(new int[] {16, 17, 18, 19, 22, 24}, prayer);
				p.headIconPrayer = 5;
			} else {
				p.headIconPrayer = -1;
			}
		}
		if (buttonId == 51) { //Smite
			prayer = 24;
			name = "Smite";
			if (!p.usingPrayer(prayer)) {
				p.switchPrayers(new int[] {16, 17, 18, 19, 22, 23}, prayer);
				p.headIconPrayer = 4;
			} else {
				p.headIconPrayer = -1;
			}
		}
		if (buttonId == 55) { //Chivalry
			prayer = 25;
			name = "Chivalry";
			if (!p.usingPrayer(prayer)) p.switchPrayers(new int[] {0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 20, 21, 26}, prayer);
		}
		if (buttonId == 57) { //Piety
			prayer = 26;
			name = "Piety";
			if (!p.usingPrayer(prayer)) p.switchPrayers(new int[] {0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 20, 21, 25}, prayer);
		}
		if (!p.canPray(prayer)) {
			p.headIconPrayer = -1;
			if (p.getLevelForXP(5) < p.prayers[prayer][0] && p.skillLvl[5] > 0) {
				p.getActionSender().dialogue(p, -1, -1, "", 1, "You need a <col=000080>Prayer</col> level of "+(int)p.prayers[prayer][0]+" to use <col=000080>"+name, "", "", "");
			}
			break;
		}
		if (prayer == 25 && p.getLevelForXP(1) < 60) {
			p.getActionSender().dialogue(p, -1, -1, "", 1, "You need a <col=000080>Defence</col> level of 60 to use <col=000080>"+name, "", "", "");
			break;
		}
		if (prayer == 26 && p.getLevelForXP(1) < 70) {
			p.getActionSender().dialogue(p, -1, -1, "", 1, "You need a <col=000080>Defence</col> level of 70 to use <col=000080>"+name, "", "", "");
			break;
		}
		p.togglePrayer(prayer, p.usingPrayer(prayer) ? 0 : 1);
		if (p.usingPrayer(prayer)) {
			p.prayerSounds(prayer);
		} else {
			p.getActionSender().addSoundEffect(p, 2663, 1, 0, 0);
		}
		p.updateReq = true;
		p.appearanceUpdateReq = true;
	break;

        case 750:
            /*
             * Running button next to minimap.
             */
        case 261:
            /*
             * Settings tab.
             */
            if (buttonId == 1) {
                if (!p.isRunning) {
                    p.isRunning = true;
                    p.getActionSender().setConfig(p, 173, 1);
                } else {
                    p.isRunning = false;
                    p.getActionSender().setConfig(p, 173, 0);
                }
            } else if (buttonId == 14) {
                p.getActionSender().showInterface(p, 742);
            } else if (buttonId == 16) {
                p.getActionSender().showInterface(p, 743);
            }
            break;

	case 192:
	case 193:
	case 430:
		PlayerMagic playerMagic = new PlayerMagic(p);
		playerMagic.magic(interfaceId, buttonId);
	break;

        case 464:
            /*
             * Emote tab.
             */
            if (buttonId == 2) // Yes
                p.requestAnim(855, 0);
            else if (buttonId == 3) // No
                p.requestAnim(856, 0);
            else if (buttonId == 4) // Bow
                p.requestAnim(858, 0);
            else if (buttonId == 5) // Angry
                p.requestAnim(859, 0);
            else if (buttonId == 6)  // Think
                p.requestAnim(857, 0);
            else if (buttonId == 7) // Wave
                p.requestAnim(863, 0);
            else if (buttonId == 8) // Shrug
                p.requestAnim(2113, 0);
            else if (buttonId == 9) // Cheer
                p.requestAnim(862, 0);
            else if (buttonId == 10) // Beckon
                p.requestAnim(864, 0);
            else if (buttonId == 11) // Laugh
                p.requestAnim(861, 0);
            else if (buttonId == 12) // Joy jump
                p.requestAnim(2109, 0);
            else if (buttonId == 13) // Yawn
                p.requestAnim(2111, 0);
            else if (buttonId == 14) // Dance
                p.requestAnim(866, 0);
            else if (buttonId == 15) // Jig
                p.requestAnim(2106, 0);
            else if (buttonId == 16) // Spin
                p.requestAnim(2107, 0);
            else if (buttonId == 17) // Headbang
                p.requestAnim(2108, 0);
            else if (buttonId == 18) // Cry
                p.requestAnim(860, 0);
            else if (buttonId == 19) { // Blow kiss
                p.requestGFX(574, 0);
                p.requestAnim(0x558, 0);
            } else if (buttonId == 20) // Panic
                p.requestAnim(2105, 0);
            else if (buttonId == 21) // Raspberry
                p.requestAnim(2110, 0);
            else if (buttonId == 22) // Clap
                p.requestAnim(865, 0);
            else if (buttonId == 23) // Salute
                p.requestAnim(2112, 0);
            else if (buttonId == 24) // Goblin bow
                p.requestAnim(0x84F, 0);
            else if (buttonId == 25) // Goblin salute
                p.requestAnim(0x850, 0);
            else if (buttonId == 26) // Glass box
                p.requestAnim(1131, 0);
            else if (buttonId == 27) // Climb rope
                p.requestAnim(1130, 0);
            else if (buttonId == 28) // Lean
                p.requestAnim(1129, 0);
            else if (buttonId == 29) // Glass wall
                p.requestAnim(1128, 0);
            else if (buttonId == 30) // Head slap
                p.requestAnim(4275, 0);
            else if (buttonId == 31) // Stomp
                p.requestAnim(1745, 0);
            else if (buttonId == 32) // Flap
                p.requestAnim(4280, 0);
            else if (buttonId == 33) // Idea
                p.requestAnim(4276, 0);
            else if (buttonId == 34) // Zombie walk
                p.requestAnim(3544, 0);
            else if (buttonId == 35) // Dombie dance
                p.requestAnim(3543, 0);
            else if (buttonId == 36) { // Zombie hand grab
                p.requestGFX(1244, 0);
                p.requestAnim(7272, 0);
            } else if (buttonId == 37) // Scared
                p.requestAnim(2836, 0);
            else if (buttonId == 38) // Rabbit hop
                p.requestAnim(6111, 0);
            else if (buttonId == 39) { // Skillcape emotes
			if (!p.skillCapeEquiped()) {
				p.getActionSender().sendMessage(p, "You need a skill cape equiped to perform this animation.");
				return;
			}
			if (p.animClickDelay > 0) {
				return;
			}
			if (p.equipment[1] == 9747 || p.equipment[1] == 10639 || p.equipment[1] == 9748) { //attack
                    		p.requestGFX(823,1);
	    	    		p.requestAnim(4959,1);
                	}
			if (p.equipment[1] == 9753 || p.equipment[1] == 10641 || p.equipment[1] == 9754) { //Defence
                    		p.requestGFX(824,1);
	    			p.requestAnim(4961,1);
                	}
			if (p.equipment[1] == 9750 || p.equipment[1] == 10640 || p.equipment[1] == 9751) { //Strength
                    		p.requestGFX(828,1);
	    			p.requestAnim(4981,1);
                	}
			if (p.equipment[1] == 9768 || p.equipment[1] == 10647 || p.equipment[1] == 9769) { //Hitpoints
                    		p.requestGFX(833,1);
	    			p.requestAnim(4971,1);
                	}
			if (p.equipment[1] == 9756 || p.equipment[1] == 10642 || p.equipment[1] == 9757) { //Range
                    		p.requestGFX(832,1);
	    			p.requestAnim(4973,1);
                	}
			if (p.equipment[1] == 9759 || p.equipment[1] == 10643 || p.equipment[1] == 9760) { //Prayer
                    		p.requestGFX(829,1);
	    			p.requestAnim(4979,1);
                	}
			if (p.equipment[1] == 9762 || p.equipment[1] == 10644 || p.equipment[1] == 9763) { //Magic
                    		p.requestGFX(813,1);
	    			p.requestAnim(4939,1);
                	}
			if (p.equipment[1] == 9801 || p.equipment[1] == 10658 || p.equipment[1] == 9802) { //Cooking
                    		p.requestGFX(821,1);
	    			p.requestAnim(4955,1);
                	}
			if (p.equipment[1] == 9807 || p.equipment[1] == 10660 || p.equipment[1] == 9808) { //Woodcutting
                    		p.requestGFX(822,1);
	    			p.requestAnim(4957,1);
                	}
			if (p.equipment[1] == 9783 || p.equipment[1] == 10652 || p.equipment[1] == 9784) { //Fletching
                    		p.requestGFX(812, 1);
	    			p.requestAnim(4937, 1);
                	}
			if (p.equipment[1] == 9798 || p.equipment[1] == 10657 || p.equipment[1] == 9799) { //Fishing
                   		p.requestGFX(819,1);
	    			p.requestAnim(4951,1);
                	}
			if (p.equipment[1] == 9804 || p.equipment[1] == 10659 || p.equipment[1] == 9805) { //Firemaking
                    		p.requestGFX(831,1);
	   			p.requestAnim(4975,1);
                	}
			if (p.equipment[1] == 9780 || p.equipment[1] == 10651 || p.equipment[1] == 9781) { //Crafting
                    		p.requestGFX(818,1);
	   			p.requestAnim(4949,1);
                	}
			if (p.equipment[1] == 9795 || p.equipment[1] == 10656 || p.equipment[1] == 9796) { //Smithing
                    		p.requestGFX(815,1);
	    			p.requestAnim(4943,1);
                	}
			if (p.equipment[1] == 9792 || p.equipment[1] == 10655 || p.equipment[1] == 9793) { //Mining
                    		p.requestGFX(814,1);
	    			p.requestAnim(4941,1);
                	}
			if (p.equipment[1] == 9774 || p.equipment[1] == 10649 || p.equipment[1] == 9775) { //Herblore
                    		p.requestGFX(835,1);
	    			p.requestAnim(4969,1);
                	}
			if (p.equipment[1] == 9771 || p.equipment[1] == 10648 || p.equipment[1] == 9772) { //Agility
                    		p.requestGFX(830,1);
	    			p.requestAnim(4977,1);
                	}
			if (p.equipment[1] == 9777 || p.equipment[1] == 10650 || p.equipment[1] == 9778) { //Theiving
                    		p.requestGFX(826,1);
	    			p.requestAnim(4965,1);
                	}
			if (p.equipment[1] == 9786 || p.equipment[1] == 10653 || p.equipment[1] == 9787) { //Slayer
                    		p.requestGFX(1656, 1);
	   			p.requestAnim(4967, 1);
                	}
			if (p.equipment[1] == 9810 || p.equipment[1] == 10661 || p.equipment[1] == 9811) { //Farming
                    		p.requestGFX(825,1);
	    			p.requestAnim(4963,1);
                	}
			if (p.equipment[1] == 9765 || p.equipment[1] == 10645 || p.equipment[1] == 9766) { //Runecrafting
                    		p.requestGFX(817,1);
	    			p.requestAnim(4947,1);
                	}
			if (p.equipment[1] == 9789 || p.equipment[1] == 10654 || p.equipment[1] == 9790) { //Construction
                   		 p.requestGFX(820,1);
	    			p.requestAnim(4953,1);
                	}
			if (p.equipment[1] == 12524 || p.equipment[1] == 12169 || p.equipment[1] == 12170) { //Summoning
                    		p.requestGFX(1515,1);
	    			p.requestAnim(8525,1);
                	}
			if (p.equipment[1] == 9948 || p.equipment[1] == 10646 || p.equipment[1] == 9949) { // hunter
            			p.requestGFX(907, 0);
            			p.requestAnim(5158, 0);
          		}
			if (p.equipment[1] == 9813 || p.equipment[1] == 10662) { //Quest
                    		p.requestGFX(816,1);
	    			p.requestAnim(4945,1);
                	}
			p.animClickDelay = 10;
	    }
            else if (buttonId == 40) // Snowman dance
                p.requestAnim(7531, 0); 
            else if (buttonId == 41) { // Air guitar
                p.requestAnim(2414, 0);
                p.requestGFX(1537, 0);
            } else if (buttonId == 42)  { // Safety first
                p.requestAnim(8770, 0); 
                p.requestGFX(1553, 0);
            }
        break;
	case 335:
	case 334:
	case 336:
		p.pTrade.buttons.handleButton(interfaceId, packetId, buttonId, buttonId2);
	break;

	case 75:
	case 76:
	case 77:
	case 78:
	case 79:
	case 80:
	case 81:
	case 82:
	case 83:
	case 84:
	case 85:
	case 86:
	case 87:
	case 88:
	case 89:
	case 91:
	case 92:
	case 93:
		if (buttonId == 2) {
			p.fightStyle = 1;
		}
		if (buttonId == 3) {
			p.fightStyle = 2;
		}
		if (buttonId == 4) {
			p.fightStyle = 3;
		}
		if (buttonId == 5) {
			p.fightStyle = 4;
		}
		if (buttonId == 24 || buttonId == 26 || buttonId == 27) {
			p.autoRetaliate ^= true;
			p.getActionSender().setConfig(p, 172, p.autoRetaliate ? 0 : 1);
		}
		if (buttonId == 8 || buttonId == 10 || buttonId == 11) {
			if (p.specAmount == 0) {
				p.getActionSender().sendMessage(p, "You do not have enough special energy.");
				p.usingSpecial = false;
				p.getActionSender().setConfig(p, 301, 0);
				break;
			}
			p.usingSpecial ^= true;
			if (p.equipment[3] == 4153) {
				if (p.attacking != null) {
					if (p.specAmount >= 500) {
						p.combatDelay = 0;
						p.usingSpecial = true;
						p.getActionSender().setConfig(p, 301, 1);
						p.attackPlayer();
					}
				}
			}
			p.getActionSender().setConfig(p, 301, p.usingSpecial ? 1 : 0);
		}

            	Misc.println("[" + p.username + "] Unhandled button: " + interfaceId + ", " + buttonId + ":" + buttonId2);
	break;

	case 274:
	if (buttonId == 10) {//Home
      if (p.wildernessZone(p.absX, p.absY)) {
      p.getActionSender().sendMessage(p, "You cannot teleport while inside a PvP zone.");
      return;
      }		
      p.teleportTo(3093, 3492, 0, 4, 0, 8939, 8941, 1576, 0, 1577, 0);
      }
	else if (buttonId == 11) {//Ancients
      if (p.wildernessZone(p.absX, p.absY)) {
      p.getActionSender().sendMessage(p, "You cannot teleport while inside a PvP zone.");
      return;
      }		
	  p.teleportTo(3232, 9312, 0, 4, 0, 8939, 8941, 1576, 0, 1577, 0);
	  p.requestGFX(392, 0);
      p.requestAnim(9599, 0);
	  p.requestGFX(455, 0);	  
	  }
	else if (buttonId == 12) {//Lunars
	  if (p.wildernessZone(p.absX, p.absY)) {
      p.getActionSender().sendMessage(p, "You cannot teleport while inside a PvP zone.");
      return;
      }	
	  p.teleportTo(2156, 3864, 0, 4, 0, 8939, 8941, 1576, 0, 1577, 0);
	  p.requestGFX(1685, 0);
      p.requestAnim(9606, 0);
	  }
	else if (buttonId == 13) {//Mage's Bank 
      if (p.wildernessZone(p.absX, p.absY)) {
      p.getActionSender().sendMessage(p, "You cannot teleport while inside a PvP zone.");
      return;
      }		
      p.teleportTo(3090, 3956, 4, 4, 0, 8939, 8941, 1576, 0, 1577, 0);
	  }		  				
	else if (buttonId == 14) {//Mage Arena	
      if (p.wildernessZone(p.absX, p.absY)) {
      p.getActionSender().sendMessage(p, "You cannot teleport while inside a PvP zone.");
      return;
      }		
      p.teleportTo(3104, 3933, 4, 4, 0, 8939, 8941, 1576, 0, 1577, 0);
	  }
	else if (buttonId == 15) {//PvP	
      if (p.wildernessZone(p.absX, p.absY)) {
      p.getActionSender().sendMessage(p, "You cannot teleport while inside a PvP zone.");
      return;
      }	
      p.teleportTo(3087, 3503, 4, 4, 0, 8939, 8941, 1576, 0, 1577, 0);
	  } 
    else if (buttonId == 18) {//Max str set
      if (p.wildernessZone(p.absX, p.absY)) {
      p.getActionSender().sendMessage(p, "You cannot spawn while inside a PvP zone.");
      return;
      }
      Engine.playerItems.addItem(p, 11724, 1);
      Engine.playerItems.addItem(p, 11726, 1);
      Engine.playerItems.addItem(p, 10828, 1);
      Engine.playerItems.addItem(p, 6737, 1);
      Engine.playerItems.addItem(p, 6585, 1);
      Engine.playerItems.addItem(p, 6570, 1);
      Engine.playerItems.addItem(p, 11283, 1);
      Engine.playerItems.addItem(p, 4151, 1);
      Engine.playerItems.addItem(p, 7462, 1);
      Engine.playerItems.addItem(p, 11732, 1);
	  Engine.playerItems.addItem(p, 5698, 1);
      }	
    else if (buttonId == 19) {//Dharok's
      if (p.wildernessZone(p.absX, p.absY)) {
      p.getActionSender().sendMessage(p, "You cannot spawn while inside a PvP zone.");
      return;
      }	
      Engine.playerItems.addItem(p, 4716, 1);	
      Engine.playerItems.addItem(p, 4718, 1);	
      Engine.playerItems.addItem(p, 4720, 1);		  	  
      Engine.playerItems.addItem(p, 4722, 1);
      }	  
	  else if (buttonId == 20) {//AGS	
      if (p.wildernessZone(p.absX, p.absY)) {
      p.getActionSender().sendMessage(p, "You cannot spawn while inside a PvP zone.");
      return;
      }	  
      Engine.playerItems.addItem(p, 11694, 1);	
	  }
    else if (buttonId == 21) {//BGS
      if (p.wildernessZone(p.absX, p.absY)) {
      p.getActionSender().sendMessage(p, "You cannot spawn while inside a PvP zone.");
      return;
      }	
      Engine.playerItems.addItem(p, 11696, 1);	
	  }	
    else if (buttonId == 22) {//SGS
      if (p.wildernessZone(p.absX, p.absY)) {
      p.getActionSender().sendMessage(p, "You cannot spawn while inside a PvP zone.");
      return;
      }	
	  Engine.playerItems.addItem(p, 11698, 1);	
	  }
    else if (buttonId == 23) {//ZGS
      if (p.wildernessZone(p.absX, p.absY)) {
      p.getActionSender().sendMessage(p, "You cannot spawn while inside a PvP zone.");
      return;
      }	
	  Engine.playerItems.addItem(p, 11700, 1);	  
	  }
	else if (buttonId == 24) {//Max str set for zerk
      if (p.wildernessZone(p.absX, p.absY)) {
      p.getActionSender().sendMessage(p, "You cannot spawn while inside a PvP zone.");
      return;
      }
      Engine.playerItems.addItem(p, 3751, 1);
      Engine.playerItems.addItem(p, 10551, 1);
      Engine.playerItems.addItem(p, 6130, 1);
      Engine.playerItems.addItem(p, 6737, 1);
      Engine.playerItems.addItem(p, 6585, 1);
      Engine.playerItems.addItem(p, 6570, 1);
      Engine.playerItems.addItem(p, 8850, 1);
      Engine.playerItems.addItem(p, 4151, 1);
      Engine.playerItems.addItem(p, 7462, 1);
      Engine.playerItems.addItem(p, 4131, 1);
      Engine.playerItems.addItem(p, 5698, 1);
      } 
    else if (buttonId == 26) {//Ticket
	  if (p.rights > 0) {
	   p.getActionSender().sendMessage(p, "You are staff! Do not abuse the ticket system!");
	   return;
	  }
	   p.getActionSender().sendMessage(p, "Do not abuse the ticket system or you may be banned.");
		for (Player pl : Server.engine.players) {
		 if (pl != null && pl.rights > 0) {
	     pl.getActionSender().sendMessage(pl, "<col=8B0000>"+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+" is requesting staff assistance!");  
	    }	
      }
    }	
	break;
	
	case 90:
		for (int i = 0; i < p.regularStaffs.length; i++) {
			if (p.equipment[3] == p.regularStaffs[i]) {
				if (buttonId == 4) {
					p.getActionSender().setTab(p, 73, 319);
				}
			}
		}
		for (int a = 0; a < p.otherStaffs.length; a++) {
			if (p.equipment[3] == p.otherStaffs[a]) {
				if (buttonId == 4) {
					p.getActionSender().setTab(p, 73, 388);
				}
			}
		}
	break;

	case 319:
		if (buttonId == 15) {
			p.autoCast[0] = 16;
			p.castAuto = true;
		}
		if (buttonId != 16)
			p.getActionSender().sendMessage(p, "You are now using autocast.");
		p.getActionSender().setTab(p, 73, 90);
		p.playerWeapon.setWeapon();
	break;

	case 388:
		if (buttonId == 15) {
			p.autoCast[1] = 16;
			p.castAuto = true;
		}
		if (buttonId != 16)
			p.getActionSender().sendMessage(p, "You are now using autocast.");
		p.getActionSender().setTab(p, 73, 90);
		p.playerWeapon.setWeapon();
	break;

	case 182:
		if (p.attackedBy == null && p.logoutTimer == 0) {
			try {
				p.usedLogout = true;
				Engine.fileManager.saveCharacter(p);
				p.getActionSender().logout(p);
			} catch (Exception e) {
			}
		} else {
			p.getActionSender().sendMessage(p, "You cannot logout while in combat.");
		}
	break;

        case 548:
            break;
case 746:
if(buttonId == 49) //music tab
p.getActionSender().setInterface(p, 1, 746, 71, 187);
else if (buttonId == 48) //emote tab
p.getActionSender().setInterface(p, 1, 746, 71, 464);
else if (buttonId == 47) //setting tab
p.getActionSender().setInterface(p, 1, 746, 71, 261);
else if (buttonId == 46) //clan chat
p.getActionSender().setInterface(p, 1, 746, 71, 589);
else if (buttonId == 45) //ignore tab
p.getActionSender().setInterface(p, 1, 746, 71, 551);
else if (buttonId == 44) //friends list tab
p.getActionSender().setInterface(p, 1, 746, 71, 550);
else if (buttonId == 42) //magic tab
p.getActionSender().setInterface(p, 1, 746, 71, 192);
else if (buttonId == 41) //prayer tab
p.getActionSender().setInterface(p, 1, 746, 71, 271);
else if (buttonId == 40) //Equipment tab
p.getActionSender().setInterface(p, 1, 746, 71, 387);
else if (buttonId == 39) //Inventory tab
p.getActionSender().setInterface(p, 1, 746, 71, 149); 
else if (buttonId == 38) //quest tab
p.getActionSender().setInterface(p, 1, 746, 71, 274);
  
else if (buttonId == 37) //Skill tab
p.getActionSender().setInterface(p, 1, 746, 71, 320); 
else if (buttonId == 36) {//Attack tab 
p.playerWeapon.setWeapon();
p.getActionSender().setInterface(p, 1, 746, 71, 92);
}
else if (buttonId == 35) //sum tab 
p.getActionSender().setInterface(p, 1, 746, 71, 92); 
else if (buttonId == 12) //Logout.
p.getActionSender().setInterface(p, 1, 746, 71, 182);
		break;
        case 763:
            /*
             * Inventory interface with banking.
             */
            if (p.interfaceId != 762) {
                return;
            }
            if (buttonId == 0) {
                if (packetId == 233)
                    Engine.playerBank.bankItem(p, buttonId2, 1);
                else if (packetId == 21)
                    Engine.playerBank.bankItem(p, buttonId2, 5);
                else if (packetId == 169)
                    Engine.playerBank.bankItem(p, buttonId2, 10);
		else if (packetId == 214)
		    Engine.playerBank.bankItem(p, buttonId2, 50);
		else if (packetId == 173)
		    Engine.playerBank.bankItem(p, buttonId2, 100);
                else if (packetId == 232)
                    Engine.playerBank.bankItem(p, buttonId2, -100);
            }
            break;
	case 637:
            Misc.println("[" + p.username + "] Unhandled button: " + interfaceId + ", " + buttonId + ":" + buttonId2);
	    if (buttonId == 14) {
		Player pl = Server.engine.players[p.duelFriend];
		if (p != null && pl != null) {
			p.getActionSender().removeShownInterface(p);
			pl.getActionSender().removeShownInterface(pl);
			p.getDuelClass().resetDuelSettings1();
	        	pl.getDuelClass().resetDuelSettings1();
		}
	    }
	    if (buttonId == 83) {/* Accept */
		Player pl = Server.engine.players[p.duelFriend];
		if (p != null && pl != null) {
			p.acceptScreen1 = true;
			p.getActionSender().sendMessage(p, "Accepted duel.");
		}
	    }
	    if (buttonId == 86) {/* Decline */
		Player pl = Server.engine.players[p.duelFriend];
		if (p != null && pl != null) {
			p.getActionSender().removeShownInterface(p);
			pl.getActionSender().removeShownInterface(pl);
			p.getDuelClass().resetDuelSettings1();
	        	pl.getDuelClass().resetDuelSettings1();
		}
	    }
	    break;
	case 640:
	    if (buttonId == 18) {
		p.getActionSender().removeShownInterface(p);
		p.teleportTo(3087 + Misc.random(2), 3518 + Misc.random(2), 0, 4, 0, 8939, 8941, 1576, 0, 1577, 0);
	    }
	    if (buttonId == 19) {
		p.getActionSender().removeShownInterface(p);
		p.teleportTo(3243 + Misc.random(8), 3533 + Misc.random(8), 0, 4, 0, 8939, 8941, 1576, 0, 1577, 0);
	    }
	    if (buttonId == 20) {
		p.getActionSender().removeShownInterface(p);
		p.teleportTo(3091 + Misc.random(2), 3963 + Misc.random(2), 0, 4, 0, 8939, 8941, 1576, 0, 1577, 0);
	    }
	break;
        case 762:
            /*
             * Bank interface.
             */
            if (p.interfaceId != 762) {
                return;
            }
            if (buttonId == 73) {
                if (packetId == 233)
                    Engine.playerBank.bankWithdraw(p, buttonId2, 1);
                else if (packetId == 21)
                    Engine.playerBank.bankWithdraw(p, buttonId2, 5);
                else if (packetId == 169)
                    Engine.playerBank.bankWithdraw(p, buttonId2, 10);
		else if (packetId == 214)
		    Engine.playerBank.bankWithdraw(p, buttonId2, 50);
		else if (packetId == 173)
		    Engine.playerBank.bankWithdraw(p, buttonId2, 100);
                else if (packetId == 232)
                    Engine.playerBank.bankWithdraw(p, buttonId2, -100);
            }
            break;
        default:
            Misc.println("[" + p.username + "] Unhandled button: " + interfaceId + ", " + buttonId + ":" + buttonId2);
            break;
        }
    }
}