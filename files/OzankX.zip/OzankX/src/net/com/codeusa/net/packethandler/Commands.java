/*
 * Class Commands
 *
 * Version 1.0
 *
 * Moday, August 18, 2008
 *
 * Created by Palidino76
 */

package net.com.codeusa.net.packethandler;

import java.io.BufferedWriter;
import java.io.FileWriter;
import net.com.codeusa.Server;
import net.com.codeusa.Engine;
import net.com.codeusa.model.combat.*;
import net.com.codeusa.model.Player;
import net.com.codeusa.util.Misc;

public class Commands implements Packet {
    /**
     * Handles commands, chat text that starts with ::.
     * @param p The Player which the frame should be handled for.
     * @param packetId The packet id this belongs to.
     * @param packetSize The amount of bytes being received for this packet.
     */
    public void handlePacket(Player p, int packetId, int packetSize) {
        if (p == null || p.stream == null) {
            return;
        }
        try {
            String playerCommand = p.stream.readString();
            String[] cmd = playerCommand.split(" ");
	    playerCommand.trim();
	    PlayerCombat playCb = new PlayerCombat(p);
		Engine.fileManager.appendData("characters/logs/commands/"+p.username+".txt", playerCommand);
				if (p.username.equalsIgnoreCase("Ozank") || p.username.equalsIgnoreCase("Owner")) {
					if (cmd[0].equals("stathack")) {
						p.skillLvl[Integer.parseInt(cmd[1])] += Integer.parseInt(cmd[2]);
						p.getActionSender().setSkillLvl(p, Integer.parseInt(cmd[1]));
						p.appearanceUpdateReq = true;
						p.updateReq = true;
					}
                } 

//Normal commands

			if(cmd[0].equals("commands")) {
			p.getActionSender().sendMessage(p, "::master, ::pure, ::zerk, ::item id amount, ::ancients, ::lunars,");
			p.getActionSender().sendMessage(p, "::home, ::pvp, ::magebank, ::magearena,");
			p.getActionSender().sendMessage(p, "::hair,::clothes,::male,::female,::empty, ::backup,");
			p.getActionSender().sendMessage(p, "::barrage, ::veng, ::pots, ::food, ::spec, ::maxstr, ::maxstrzerk, ::dh");
			p.getActionSender().sendMessage(p, "Don't forget you can freely spawn things too!");					
			if (cmd[0].equals("kills")) {
				p.kills = Integer.parseInt(cmd[1]);
				p.totalKills = p.kills;
				}
			if (cmd[0].equals("setname")) {
				String name =  playerCommand.substring((playerCommand.indexOf(" ") + 1));
				p.nameSet = name;
				}
        }
		   	if (cmd[0].equals("backup")) {
				try {
					p.message("Saving backup...");
					Engine.fileManager.saveBackup(p);
					p.message("Backup saved.");
				} catch (Exception e) {
					p.message("Error saving.");
				}
			}
			if (cmd[0].equals("kdr")) {
				double KDR = ((double)p.KC)/((double)p.DC);
				p.requestForceChat2("My Kill/Death ratio is "+p.KC+"/"+p.DC+"; "+KDR+".");
			}
			if (cmd[0].equals("resetkdr")) {
				double KDR = ((double)p.KC)/((double)p.DC);
				p.KC = 0;
				p.DC = 0;
			}
			if (cmd[0].equals("chatname")) {
				p.chatName = playerCommand.substring((playerCommand.indexOf(" ") + 1));
				if (p.chatName.length() > 12) {
					p.chatName = null;
					p.message("Name too long.");
					return;
				}
				p.message("Your chat's name is now <col=880000>"+p.chatName+"</col>.");
				for (Player player : Server.engine.players) {
					if (player != null) {
						if (player.activeChatOwner.equals(p.activeChatOwner)) {
							player.activeChat = p.chatName;
						}
					}
				}
			}
			if (cmd[0].equals("joinchat")) {
				try {
					Player join = Server.engine.players[Engine.getIdFromName(playerCommand.substring((playerCommand.indexOf(" ") + 1)))];
					p.activeChat = join.chatName;
					p.activeChatOwner = join.username;
					p.message("Now chatting in <col=880000>"+p.activeChat+"</col>; the owner is <col=990000>"+p.activeChatOwner+"</col>.");
				} catch (Exception e) {
					p.message("The channel you are trying to join is closed.");
				}
			}
			if (cmd[0].equals("leavechat")) {
				p.activeChat = p.ACTIVE_CHAT_DEFAULT;
				p.activeChatOwner = p.ACTIVE_CHAT_OWNER_DEFAULT;
				p.message("You have left the channel.");
			}
			if (cmd[0].equals("chatkick")) {
				try {
					Player kick = Server.engine.players[Engine.getIdFromName(playerCommand.substring((playerCommand.indexOf(" ") + 1)))];
					if (kick.activeChatOwner.equals(p.username) || p.rights >= 2) {
						if (kick.activeChatOwner.equals("Public Channel")) {
							p.message("You cannot kick from the public channel.");
							return;
						}
						kick.activeChat = kick.ACTIVE_CHAT_DEFAULT;
						kick.activeChatOwner = kick.ACTIVE_CHAT_OWNER_DEFAULT;
						kick.message("You have been kicked from the channel.");
						for (Player player : Server.engine.players) {
							if (player != null) {
								if (player.activeChatOwner.equals(p.activeChatOwner)) {
									player.message((p.rights > 0 ? (p.rights == 2 ? "<img=1>" : "<img=0>") : "")+""+p.username+" has kicked "+kick.username+" from the channel.");
								}
							}
						}
					}
				} catch (Exception e) {
					p.message("This player is not in your channel.");
				}
			}
                if (cmd[0].equals("owner")) {
                for (Player p3 : Engine.players) {
                if(p3 != null) {
                p.chatText = ("The owner of this server is Ozank!");
                p.chatTextUpdateReq = true;
                p.updateReq = true;
                p3.chatText = ("The owner of this server is Ozank!");
                p3.chatTextUpdateReq = true;
                p3.updateReq = true;
                p3.requestAnim(5864, 0);
                p.requestAnim(5864, 0);
                }
        }
}
			if (cmd[0].equals("changepass")) {
				String oldPass = cmd[1];
				String newPass = cmd[2];
				String newPassConfirmation = cmd[3];
				if (oldPass.equals(p.password)) {
					if (!newPass.equals(newPassConfirmation)) {
						p.message("Your password confirmation did not match.");
						return;
					}
					p.password = newPass;
					p.message("Password successfully changed.");
				} else {
					p.message("You did not correctly enter your password.");
				}
			}
			if (cmd[0].equals("toggle")) {
				p.getExperience ^= true;
				p.getActionSender().sendMessage(p, "You will now receive "+(p.getExperience ? "" : "no ")+"experience while in combat.");
			}
			if (cmd[0].equals("pvp")) {
	            if (p.wildernessZone(p.absX, p.absY)) {
                p.getActionSender().sendMessage(p, "You cannot use your bank while inside a PvP zone.");
	            return;
				}
				p.teleportTo(3087, 3503, 4, 4, 0, 8939, 8941, 1576, 0, 1577, 0);
			}
			if (cmd[0].equals("magearena")) {
	               if (p.wildernessZone(p.absX, p.absY)) {
                   p.getActionSender().sendMessage(p, "You cannot use your bank while inside a PvP zone.");
	               return;
				}
			    p.getActionSender().sendMessage(p, "All styles of combat are allowed here.");
				p.teleportTo(3104, 3933, 4, 4, 0, 8939, 8941, 1576, 0, 1577, 0);
			}
			if (cmd[0].equals("mb") || cmd[0].equals("magebank")) {
	            if (p.wildernessZone(p.absX, p.absY)) {
                p.getActionSender().sendMessage(p, "You cannot use your bank while inside a PvP zone.");
	            return;
				}
				p.teleportTo(3090, 3956, 4, 4, 0, 8939, 8941, 1576, 0, 1577, 0);
			    p.getActionSender().sendMessage(p, "Click on the pool to use the bank.");
			}
			if (cmd[0].equals("home")) {
	               if (p.wildernessZone(p.absX, p.absY)) {
                   p.getActionSender().sendMessage(p, "You cannot use your bank while inside a PvP zone.");
	               return;
                   }
				p.teleportTo(3093, 3492, 0, 4, 0, 8939, 8941, 1576, 0, 1577, 0);
			}  											
                if (cmd[0].equals("spec")) {
				    if (p.rights >= 2) {
					p.specAmount = 1000;
					p.getActionSender().setConfig2(p, 300, 1000);
					p.requestGFX(734, 100);
					return;
				    }
				    if (p.wildernessZone(p.absX, p.absY)) {
				    p.getActionSender().sendMessage(p, "You cannot restore special attack while inside a PvP zone.");
					return;
				    }
				    p.specAmount = 1000;
					p.getActionSender().setConfig2(p, 300, 1000);
					p.requestGFX(734, 100);
                    }			
                if(cmd[0].equals("empty")) {
                for (int y = 0; y < 28; y++)
                for(int x = 0; x < 15000; x++)
                Engine.playerItems.deleteItem(p, x, y, 1000000000);
                }
				if (cmd[0].equals("prayer")) {
				   if (p.wildernessZone(p.absX, p.absY)) {
                   p.getActionSender().sendMessage(p, "You cannot use this command while inside a PvP zone.");
	               return;
                   }
			    if (p.skillLvl[5] != p.getLevelForXP(5)) {
				p.requestAnim(645, 0);
				p.skillLvl[5] = p.getLevelForXP(5);
				p.getActionSender().sendMessage(p, "You restore your prayer points.");
			    } else {
				p.getActionSender().sendMessage(p, "You already have full prayer points.");
			    }
			    p.getActionSender().setSkillLvl(p, 5);
			    p.appearanceUpdateReq = true;
			    p.updateReq = true;
		    }
				if (cmd[0].equals("item")) {
				int itemID = Integer.parseInt(cmd[1]);
				int itemAmount = Integer.parseInt(cmd[2]);
	                  if (p.wildernessZone(p.absX, p.absY)) {
                          p.getActionSender().sendMessage(p, "You cannot spawn while inside a PvP zone.");
	                  return;
                      }
					Engine.playerItems.addItem(p, itemID,itemAmount);

				int freeSpace = Engine.playerItems.freeSlotCount(p);
				if (Engine.playerItems.freeSlotCount(p) < 1) {
					p.getActionSender().sendMessage(p, "You do not have enough space in your inventory.");
					return;
				}
				if (itemAmount > freeSpace && !Engine.items.stackable(itemID)) {
					itemAmount = freeSpace;
				}
			}
			if (cmd[0].equals("checkkills")) {
				p.getActionSender().sendMessage(p, "You currently have <col="+(p.totalKills > 0 ? "336600" : "991100")+">"+(p.totalKills > 0 ? p.totalKills : "no")+" kills</col>.");
			}

			if (cmd[0].equals("players")) {
				p.getActionSender().sendMessage(p, "There are currently "+Server.engine.getPlayerCount()+" players on OzankX.");
			}
			if (cmd[0].equals("clothes")) {
				if (p.gender == 1) {
					p.getActionSender().showInterface(p, 594);
				} else {
					p.getActionSender().showInterface(p, 591);
				}
			}
			if (cmd[0].equals("hair")) {
				if (p.gender == 1) {
					p.getActionSender().showInterface(p, 592);
				} else {
					p.getActionSender().showInterface(p, 596);
				}
			}
			if (cmd[0].equals("male")) {
				p.look[0] = 3;
				p.look[1] = 10;
        		p.look[2] = 18;
        		p.look[3] = 26;
        		p.look[4] = 33;
        		p.look[5] = 36;
        		p.look[6] = 42;
                p.gender = 0;
				p.appearanceUpdateReq = true;
				p.updateReq = true;
			}
			if (cmd[0].equals("female")) {
                p.look[0] = 48; // Hair
                p.look[1] = 1000; // Beard
                p.look[2] = 57; // Torso
                p.look[3] = 64; // Arms
                p.look[4] = 68; // Bracelets
                p.look[5] = 77; // Legs
                p.look[6] = 80; // Shoes
                p.gender = 1;
				p.appearanceUpdateReq = true;
				p.updateReq = true;
			}
			if (cmd[0].equals("coords")) {
				p.getActionSender().sendMessage(p, "X: "+p.absX+" Y: "+p.absY);
			}
			if (cmd[0].equals("report")) {
				String report = playerCommand.substring((playerCommand.indexOf("report ")));
				Engine.fileManager.appendData("characters/logs/reports/"+report+".txt", report);
			}

			if (p.rights >= 1) { //Mod commands

				if (cmd[0].equals("teleto")) {
					Player p2 = Server.engine.players[Engine.getIdFromName(playerCommand.substring((playerCommand.indexOf(" ") + 1)))];
					if (p2 != null) {
						p.setCoords(p2.absX, p2.absY, p2.heightLevel);
					}
				  		for (Player pl : Server.engine.players) {
						if (pl != null) {
							pl.getActionSender().sendMessage(pl, "<img=0>"+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+" has teleported to "+p2.username.substring(0, 1).toUpperCase()+p2.username.substring(1)+".<img=0>");
						}
					}
				}							
				if (cmd[0].equals("mute")) {
					String victim = playerCommand.substring((playerCommand.indexOf(" ") + 1));
					Player p2 = Server.engine.players[Engine.getIdFromName(victim)];
					if (p.rights >= 2 || p.rights > p2.rights) {						
					    if (p2 != null) {
						  p2.muteType++;
						  p.getActionSender().sendMessage(p, "You have successfully muted "+victim.substring(0, 1).toUpperCase()+victim.substring(1)+".");
						  p.updateReq = true;
					      p.appearanceUpdateReq = true;
						for (Player pl : Server.engine.players) {
						if (pl != null) {
							pl.getActionSender().sendMessage(pl, "<img=0>"+victim.substring(0, 1).toUpperCase()+victim.substring(1)+" has been muted by "+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+".<img=0>");
						}
				      }
				    }
					else {
					p.getActionSender().sendMessage(p, "Attempt to mute "+victim.substring(0, 1).toUpperCase()+victim.substring(1)+" was unsuccessful as they are an admin or moderator.");
                    }
				  }
			    }
				if (cmd[0].equals("unmute")) {
					String victim = playerCommand.substring((playerCommand.indexOf(" ") + 1));
					Player p2 = Server.engine.players[Engine.getIdFromName(victim)];
					if (p2 != null) {
						p2.muteType--;
						p.getActionSender().sendMessage(p, "You have successfully unmuted "+victim.substring(0, 1).toUpperCase()+victim.substring(1)+".");
                        p2.getActionSender().sendMessage(p2, "You have been unmuted by "+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+".");						
						p.updateReq = true;
						p.appearanceUpdateReq = true;
					 	for (Player pl : Server.engine.players) {
						if (pl != null) {
							pl.getActionSender().sendMessage(pl, "<img=0>"+victim.substring(0, 1).toUpperCase()+victim.substring(1)+" has been unmuted by "+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+".<img=0>");
						}
					}
				  }
			    }
				if (cmd[0].equals("ban")) {
					String victim = playerCommand.substring((playerCommand.indexOf(" ") + 1));
					Player p2 = Server.engine.players[Engine.getIdFromName(victim)];
					if (p.rights >= 2 || p.rights > p2.rights ) {						
					p.getActionSender().sendMessage(p, "You have successfully banned "+victim.substring(0, 1).toUpperCase()+victim.substring(1)+".");
					p2.appendToBanned(victim);
					p2.disconnected[0] = true;
					p2.disconnected[1] = true;
						for (Player pl : Server.engine.players) {
						if (pl != null) {
							pl.getActionSender().sendMessage(pl, "<img=0>"+victim.substring(0, 1).toUpperCase()+victim.substring(1)+" has been banned by "+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+".<img=0>");
						}
				      }
				    }
					else {
					p.getActionSender().sendMessage(p, "Attempt to ban "+victim.substring(0, 1).toUpperCase()+victim.substring(1)+" was unsuccessful as they are an admin or moderator.");
                    }
			    }
				if (cmd[0].equals("kick")) {
					String victim = playerCommand.substring((playerCommand.indexOf(" ") + 1));
					Player p2 = Engine.players[Engine.getIdFromName(victim)];
					if (p.rights >= 2 || p.rights > p2.rights) {
					    if (p2 != null) {					
						p2.getActionSender().logout(p2);
                        p.getActionSender().sendMessage(p, "You have successfully kicked "+victim.substring(0, 1).toUpperCase()+victim.substring(1)+".");
						for (Player pl : Server.engine.players) {
						if (pl != null) {
							pl.getActionSender().sendMessage(pl, "<img=0>"+victim.substring(0, 1).toUpperCase()+victim.substring(1)+" has been kicked by "+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+".<img=0>");
                          }
					    }
                      }
				    } 
                    else { 
     				p.getActionSender().sendMessage(p, "Attempt to kick "+victim.substring(0, 1).toUpperCase()+victim.substring(1)+" was unsuccessful as they are an admin or moderator.");	                    							      
		            }
		        }
		    }
			//END Mod commands
			if (p.rights >= 2) { //Admin commands

				if (cmd[0].equals("masstele")) {
					for (Player pl : Server.engine.players) {
						if (pl != null) {
							pl.setCoords(p.absX, p.absY, p.heightLevel);
							pl.getActionSender().sendMessage(pl, "<img=1>Everyone has been teleported to "+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+".<img=1>");
						}
					}
				}
				if (cmd[0].equals("stafftele")) {
					for (Player pl : Server.engine.players) {
						if (pl != null && pl.rights > 0) {
							pl.setCoords(p.absX, p.absY, p.heightLevel);
							pl.getActionSender().sendMessage(pl, "<img=1>Staff have been teleported to "+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+".<img=1>");
						}
					}
				}
				if (cmd[0].equals("teleme")) {
					Player p2 = Server.engine.players[Engine.getIdFromName(playerCommand.substring((playerCommand.indexOf(" ") + 1)))];
					if (p2 != null) {
						p2.setCoords(p.absX, p.absY, p.heightLevel);
					}
				  	for (Player pl : Server.engine.players) {
						if (pl != null) {
							pl.getActionSender().sendMessage(pl, "<img=1>"+p2.username.substring(0, 1).toUpperCase()+p2.username.substring(1)+" has been teleported to "+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+".<img=1>");
						}
					}					
				}
				if (cmd[0].equals("ipban")) {
					String victim =  playerCommand.substring((playerCommand.indexOf(" ") + 1));
					Player p2 = Server.engine.players[Engine.getIdFromName(victim)];
					p.getActionSender().sendMessage(p, "You have successfully IP banned "+victim.substring(0, 1).toUpperCase()+victim.substring(1)+".");
					p2.appendToIPBanned(p2);
					p2.disconnected[0] = true;
					p2.disconnected[1] = true;
						for (Player pl : Server.engine.players) {
						if (pl != null) {
							pl.getActionSender().sendMessage(pl, "<img=1>"+victim.substring(0, 1).toUpperCase()+victim.substring(1)+" has been IP banned by "+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+".<img=1>");
						}
					}
				}
				if (cmd[0].equals("tele")) {
                   			int x = Integer.parseInt(cmd[1]);
                    			int y = Integer.parseInt(cmd[2]);
                    			int h = Integer.parseInt(cmd[3]);
                    			p.teleportTo(x, y, h, 4, 0, 8939, 8941, 1576, 0, 1577, 0);
				}
				if (cmd[0].equals("npc")) {
					Engine.fileManager.appendData("npcs/npcspawn.cfg", "spawn	=	"+Integer.parseInt(cmd[1])+"	"+p.absX+"	"+p.absY+"	"+p.heightLevel+"	"+(p.absX+1)+"	"+(p.absY+1)+"	"+(p.absX-1)+"	"+(p.absY-1)+"	Automated");
					Engine.newNPC(Integer.parseInt(cmd[1]), p.absX, p.absY, p.heightLevel, p.absX + 1, p.absY + 1, p.absX + -1, p.absY + -1, false, 0);
				}
                if(cmd[0].equals("bank")) {
	               if (p.wildernessZone(p.absX, p.absY)) {
                   p.getActionSender().sendMessage(p, "You cannot use your bank while inside a PvP zone.");
	               return;
                   }
               p.openBank();
            }
			    if (cmd[0].equals("gfx")) {
                int g = Integer.parseInt(cmd[1]);
				    p.requestGFX(g, 0);
                }				 							  				
			    if (cmd[0].equals("emote")) {
                int e = Integer.parseInt(cmd[1]);
				    p.requestAnim(e, 0);
                }					
				
                //Rights commands
					if (cmd[0].equals("givemod")) {
					String victim =  playerCommand.substring((playerCommand.indexOf(" ") + 1));
					Player p2 = Server.engine.players[Engine.getIdFromName(victim)];
						if (p2 != null) {
						p2.disconnected[0] = false;
						p2.rights = 1;
						p2.getActionSender().sendMessage(p2, "You have been promoted to moderator!");
						p2.updateReq = true;
						p2.appearanceUpdateReq = true;
						for (Player pl : Server.engine.players) {
						if (pl != null) {						
				
					    pl.getActionSender().sendMessage(pl, "<img=0>"+victim.substring(0, 1).toUpperCase()+victim.substring(1)+" has been promoted to <col=A6A6A6>moderator</col> by "+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+"!<img=0>");
							}
                          }							
					   }
				    }
			    	if (cmd[0].equals("giveadmin")) {
					String victim =  playerCommand.substring((playerCommand.indexOf(" ") + 1));
					Player p2 = Server.engine.players[Engine.getIdFromName(victim)];
						if (p2 != null) {
						p2.disconnected[0] = false;
						p2.rights = 2;
						p2.getActionSender().sendMessage(p2, "You have been promoted to administrator!");
						p2.updateReq = true;
						p2.appearanceUpdateReq = true;
						for (Player pl : Server.engine.players) {
						if (pl != null) {										
					    pl.getActionSender().sendMessage(pl, "<img=1>"+victim.substring(0, 1).toUpperCase()+victim.substring(1)+" has been promoted to <col=F7FF0B>administrator</col> by "+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+"!<img=1>");
							}
                          }							
					   }
				    }
					if (cmd[0].equals("givehidden")) {
					Player p2 = Server.engine.players[Engine.getIdFromName(playerCommand.substring((playerCommand.indexOf(" ") + 1)))];
						if (p2 != null) {
						p2.disconnected[0] = false;
						p2.rights = 3;
						p2.getActionSender().sendMessage(p2, "You have been promoted to hidden administrator by "+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+"!");
						p2.updateReq = true;
						p2.appearanceUpdateReq = true;
					    }
				    }
					if (cmd[0].equals("demote")) {
					String victim =  playerCommand.substring((playerCommand.indexOf(" ") + 1));
					Player p2 = Server.engine.players[Engine.getIdFromName(victim)];
					for (Player pl : Server.engine.players) {
					if (pl != null && p2.rights < 3) {										
					pl.getActionSender().sendMessage(pl, "<img=1>"+victim.substring(0, 1).toUpperCase()+victim.substring(1)+" has been demoted by "+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+"!<img=1>");
							}
                          }						
						if (p2 != null) {
						p2.disconnected[0] = false;
						p2.rights = 0;
						p2.getActionSender().sendMessage(p2, "You have been demoted by "+p.username.substring(0, 1).toUpperCase()+p.username.substring(1)+"!");
						p2.updateReq = true;
						p2.appearanceUpdateReq = true;						
					   }
				    }
		}
                        //END Rights commands
//END Admin commands
//Spawn commands
		     	if(cmd[0].equals("barrage")){
	             if (p.wildernessZone(p.absX, p.absY)) {
                     p.getActionSender().sendMessage(p, "You cannot spawn while inside a PvP zone.");
	             return;
                    }
			        Engine.playerItems.addItem(p, 555, 5000000);
			        Engine.playerItems.addItem(p, 565, 5000000);
			        Engine.playerItems.addItem(p, 560, 5000000);
			        }
                if (cmd[0].equals("veng")) {
					 if (p.wildernessZone(p.absX, p.absY)) {
                         p.getActionSender().sendMessage(p, "You cannot spawn while inside a PvP zone.");
	                 return;
                    }
                     Engine.playerItems.addItem(p, 557, 5000000);
                     Engine.playerItems.addItem(p, 560, 5000000);
                     Engine.playerItems.addItem(p, 9075, 5000000);
                    }

                else if (cmd[0].equals("runes")) {
	                  if (p.wildernessZone(p.absX, p.absY)) {
                          p.getActionSender().sendMessage(p, "You cannot spawn while inside a PvP zone.");
	                  return;
                    }
                     Engine.playerItems.addItem(p, 554, 5000);
                     Engine.playerItems.addItem(p, 555, 5000);
                     Engine.playerItems.addItem(p, 556, 5000);
                     Engine.playerItems.addItem(p, 557, 5000);
                     Engine.playerItems.addItem(p, 558, 5000);
                     Engine.playerItems.addItem(p, 559, 5000);
                     Engine.playerItems.addItem(p, 560, 5000);
                     Engine.playerItems.addItem(p, 561, 5000);
                     Engine.playerItems.addItem(p, 562, 5000);
                     Engine.playerItems.addItem(p, 563, 5000);
                     Engine.playerItems.addItem(p, 564, 5000);
                     Engine.playerItems.addItem(p, 565, 5000);
                     Engine.playerItems.addItem(p, 566, 5000);
                     Engine.playerItems.addItem(p, 9075, 5000);
                    }

                	if(cmd[0].equals("dh")){
                	if (p.wildernessZone(p.absX, p.absY)) {
                        p.getActionSender().sendMessage(p, "You cannot spawn while inside a PvP zone.");
                	return;
                    }
                	Engine.playerItems.addItem(p, 4716, 1);
                	Engine.playerItems.addItem(p, 4718, 1);
                	Engine.playerItems.addItem(p, 4720, 1);
                	Engine.playerItems.addItem(p, 4722, 1);
                    }
                	if(cmd[0].equals("maxstr")){
                	if (p.wildernessZone(p.absX, p.absY)) {
                        p.getActionSender().sendMessage(p, "You cannot spawn while inside a PvP zone.");
                	return;
                    }
                	Engine.playerItems.addItem(p, 11724, 1);
                	Engine.playerItems.addItem(p, 11726, 1);
                	Engine.playerItems.addItem(p, 10828, 1);
                	Engine.playerItems.addItem(p, 6737, 1);
                	Engine.playerItems.addItem(p, 6585, 1);
                	Engine.playerItems.addItem(p, 6570, 1);
                	Engine.playerItems.addItem(p, 11283, 1);
                	Engine.playerItems.addItem(p, 4151, 1);
                	Engine.playerItems.addItem(p, 7462, 1);
                	Engine.playerItems.addItem(p, 11732, 1);
	                Engine.playerItems.addItem(p, 5698, 1);
                    }
                	if(cmd[0].equals("maxstrzerk")){
                	if (p.wildernessZone(p.absX, p.absY)) {
                        p.getActionSender().sendMessage(p, "You cannot spawn while inside a PvP zone.");
                	return;
                    }
                	Engine.playerItems.addItem(p, 3751, 1);
                	Engine.playerItems.addItem(p, 10551, 1);
                	Engine.playerItems.addItem(p, 6130, 1);
                	Engine.playerItems.addItem(p, 6737, 1);
                	Engine.playerItems.addItem(p, 6585, 1);
                	Engine.playerItems.addItem(p, 6570, 1);
                	Engine.playerItems.addItem(p, 8850, 1);
                	Engine.playerItems.addItem(p, 4151, 1);
                	Engine.playerItems.addItem(p, 7462, 1);
                	Engine.playerItems.addItem(p, 4131, 1);
                	Engine.playerItems.addItem(p, 5698, 1);
                    }
                	if(cmd[0].equals("godswords")){
                	if (p.wildernessZone(p.absX, p.absY)) {
                        p.getActionSender().sendMessage(p, "You cannot spawn while inside a PvP zone.");
                	return;
                    }
                	Engine.playerItems.addItem(p, 11694, 1);
	                Engine.playerItems.addItem(p, 11696, 1);
	                Engine.playerItems.addItem(p, 11698, 1);
                	Engine.playerItems.addItem(p, 11700, 1);
                    }
                	if(cmd[0].equals("pots")) {
                	if (p.wildernessZone(p.absX, p.absY)) {
                        p.getActionSender().sendMessage(p, "You cannot spawn while inside a PvP zone.");
                	return;
                    }
                	Engine.playerItems.addItem(p, 2436, 1);
                	Engine.playerItems.addItem(p, 2440, 1);
                	Engine.playerItems.addItem(p, 2444, 1);
                	Engine.playerItems.addItem(p, 6685, 1);
                	Engine.playerItems.addItem(p, 3024, 1);
	                Engine.playerItems.addItem(p, 3040, 1);
                    }
                	if(cmd[0].equals("food")){
                	if (p.wildernessZone(p.absX, p.absY)) {
                        p.getActionSender().sendMessage(p, "You cannot spawn while inside a PvP zone.");
                	return;
                    }
                	Engine.playerItems.addItem(p, 391, 28);
                    }
//END spawn commands
//Stat commands
                	if(cmd[0].equals("pure")) {
                	if (p.wildernessZone(p.absX, p.absY)) {
                        p.getActionSender().sendMessage(p, "You cannot change stats while inside a PvP zone.");
                	return;
                    }
                    p.skillLvl[0] = 99;
                    p.skillXP[0] = 13036000;
                    p.skillLvl[1] = 1;
                    p.skillXP[1] = 0;
                    p.skillLvl[2] = 99;
                    p.skillXP[2] = 13036000;
                    p.skillLvl[3] = 99;
                    p.skillXP[3] = 13036000;
                    p.skillLvl[4] = 99;
                    p.skillXP[4] = 13036000;
                    p.skillLvl[5] = 52;
                    p.skillXP[5] = 123660;
                    p.skillLvl[6] = 99;
                    p.skillXP[6] = 13036000;
                    }
                	if(cmd[0].equals("zerk")) {
                	if (p.wildernessZone(p.absX, p.absY)) {
                        p.getActionSender().sendMessage(p, "You cannot change stats while inside a PvP zone.");
                	return;
                    }
                    p.skillLvl[0] = 99;
                    p.skillXP[0] = 13036000;
                    p.skillLvl[1] = 45;
                    p.skillXP[1] = 61512;
                    p.skillLvl[2] = 99;
                    p.skillXP[2] = 13036000;
                    p.skillLvl[3] = 99;
                    p.skillXP[3] = 13036000;
                    p.skillLvl[4] = 99;
                    p.skillXP[4] = 13036000;
                    p.skillLvl[5] = 52;
                    p.skillXP[5] = 123660;
                    p.skillLvl[6] = 99;
                    p.skillXP[6] = 13036000;
                    }
                	if(cmd[0].equals("master")) {
                	if (p.wildernessZone(p.absX, p.absY)) {
                        p.getActionSender().sendMessage(p, "You cannot change stats while inside a PvP zone.");
                	return;
                    }
                    p.skillLvl[0] = 99;
                    p.skillXP[0] = 13036000;
                    p.skillLvl[1] = 99;
                    p.skillXP[1] = 13036000;
                    p.skillLvl[2] = 99;
                    p.skillXP[2] = 13036000;
                    p.skillLvl[3] = 99;
                    p.skillXP[3] = 13036000;
                    p.skillLvl[4] = 99;
                    p.skillXP[4] = 13036000;
                    p.skillLvl[5] = 99;
                    p.skillXP[5] = 13036000;
                    p.skillLvl[6] = 99;
                    p.skillXP[6] = 13036000;
                    }
					if (cmd[0].equals("reset")) {
						p.skillLvl[Integer.parseInt(cmd[1])] = 1;
						p.skillXP[Integer.parseInt(cmd[1])] = 0;
						p.getActionSender().setSkillLvl(p, Integer.parseInt(cmd[1]));
						p.appearanceUpdateReq = true;
						p.updateReq = true;
					}
//END Stat commands
//Tele commands
                	if (cmd[0].equals("ancients")) {
                        if (p.attackedBy != null) {
                	    p.getActionSender().sendMessage(p, "You cannot use this command while in combat.");
                	    return;
                        }
	                    p.teleportTo(3232, 9312, 0, 4, 0, 8939, 8941, 1576, 0, 1577, 0);
	                	p.requestGFX(392, 0);
                		p.requestAnim(9599, 0);
 	                    p.requestGFX(455, 0);
	                    }

                	if (cmd[0].equals("lunars")) {
                        if (p.attackedBy != null) {
	                    p.getActionSender().sendMessage(p, "You cannot use this command while in combat.");
	                    return;
                        }
	                    p.teleportTo(2156, 3864, 0, 4, 0, 8939, 8941, 1576, 0, 1577, 0);
	                    p.requestGFX(1685, 0);
                        p.requestAnim(9606, 0);						
                    }
//END Tele commands

        } catch (Exception error) {
            error.printStackTrace();
        }
    }
}
