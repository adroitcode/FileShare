package net.com.codeusa.net.packethandler;

import net.com.codeusa.*;
import net.com.codeusa.model.Player;
import net.com.codeusa.model.items.PlayerItems;

/**
 *
 * @author Codeusa <Codeusa@live.com>
 */

public class ItemOnItem implements Packet {

	/**
	 * Handles item on item packet.
	 * @param player p The player which the packet will be created for.
	 * @param packetId the packet id which is activated (Which handles this class)
	 * @param packetSize the amount of bytes being received for the packet.
	 */
	public void handlePacket(Player player, int packetId, int packetSize) {
		if (player == null)
			return;
		int usedWith = player.stream.readSignedWordBigEndian();
        	int itemUsed = player.stream.readSignedWordA();
		PlayerItems pi = new PlayerItems();

		System.out.println("used with: "+usedWith+" itemUsed: "+itemUsed);
	}

}