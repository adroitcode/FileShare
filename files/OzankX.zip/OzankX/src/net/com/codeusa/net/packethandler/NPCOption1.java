package net.com.codeusa.net.packethandler;

import net.com.codeusa.Server;
import net.com.codeusa.npcs.*;
import net.com.codeusa.model.skills.FishingProtocol;
import net.com.codeusa.model.games.*;
import net.com.codeusa.model.combat.*;
import net.com.codeusa.model.Player;
import net.com.codeusa.util.Misc;

public class NPCOption1 implements Packet {
    /**
     * Handles the first NPC option.
     * @param p The Player which the frame should be handled for.
     * @param packetId The packet id this belongs to.
     * @param packetSize The amount of bytes being recieved for this packet.
     */
    public void handlePacket(Player p, int packetId, int packetSize) {
        if (p == null || p.stream == null) {
            return;
        }
        int npcId = p.stream.readUnsignedWord();
	PlayerSlayer playSlay = new PlayerSlayer(p);
	WarriorGuild wGuild = new WarriorGuild(p);
	switch (npcId) {
		case 144:
			p.setCoords(3420, 3540, 2);
			p.getActionSender().sendMessage(p, "Welcome to Slayer tower Floor #2.");
		break;

		case 149:
		case 151:
		case 157:
		case 176:
			p.getActionSender().setString(p, "Player Killing", 230, 2);
			p.getActionSender().setString(p, "Duel Arena", 230, 3);
			p.getActionSender().setString(p, "God wars", 230, 4);
			p.getActionSender().showChatboxInterface(p, 230);
			p.optionArray[0] = true;
		break;

		case 180:
			wGuild.selectDefenderTarget(p.defenderId);
		break;

		case 209:
			playSlay.appendTargetPicking();
		break;
	}
	System.out.println("Unhandled npc option 1 : "+npcId+" <- id.");
    }
}
