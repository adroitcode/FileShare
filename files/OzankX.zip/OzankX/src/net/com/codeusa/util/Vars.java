package net.com.codeusa.util;

public final class Vars {
    /*
     * Equipment slot ids.
     */
    public static int hat = 0;
    public static int cape = 1;
    public static int amulet = 2;
    public static int weapon = 3;
    public static int chest = 4;
    public static int shield = 5;
    public static int legs = 7;
    public static int hands = 9;
    public static int feet = 10;
    public static int ring = 12;
    public static int arrows = 13;

    /**
     * Bonus names.
     */
    public String[] bonusName = {"Stab", "Slash", "Crush", "Magic", "Range", "Stab", "Slash", "Crush", "Magic", "Range", "Strength", "Prayer"
    };
}